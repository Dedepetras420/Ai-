package lt.manoai.brain

/** Retas vektorius: indeksai (surūšiuoti) ir reikšmės, normalizuotas iki ilgio 1. */
class Vec(val idx: IntArray, val v: FloatArray) {
    fun dot(o: Vec): Float {
        var i = 0; var j = 0; var s = 0f
        while (i < idx.size && j < o.idx.size) {
            when {
                idx[i] == o.idx[j] -> { s += v[i] * o.v[j]; i++; j++ }
                idx[i] < o.idx[j] -> i++
                else -> j++
            }
        }
        return s
    }
}

/** Teksto apdorojimas: kaip modelis „mato“ žodžius. */
object Text {
    private val lt = mapOf(
        'ą' to 'a', 'č' to 'c', 'ę' to 'e', 'ė' to 'e', 'į' to 'i',
        'š' to 's', 'ų' to 'u', 'ū' to 'u', 'ž' to 'z'
    )

    /** Mažosios raidės, be lietuviškų nosinių/paukščiukų, be skyrybos. */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c0 in s.lowercase()) {
            val c = lt[c0] ?: c0
            sb.append(if (c.isLetterOrDigit()) c else ' ')
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    fun words(s: String): List<String> = normalize(s).split(' ').filter { it.isNotEmpty() }

    /**
     * Teksto požymiai neuroniniam tinklui („hashing trick“):
     *  - žodžiai, žodžių šaknys (lietuvių kalbos galūnėms), žodžių poros,
     *  - 3 raidžių gabaliukai (kad suprastų ir su rašybos klaidomis).
     */
    fun features(s: String, dim: Int): Vec {
        val m = HashMap<Int, Float>()
        fun add(key: String, w: Float) {
            val h = (key.hashCode() and 0x7fffffff) % dim
            m[h] = (m[h] ?: 0f) + w
        }
        val w = words(s)
        for (word in w) {
            val k = if (word in common) 0.35f else 1f
            add("w:$word", 0.6f * k)
            add("s:" + stem(word), 1f * k)
            val p = "<$word>"
            for (i in 0..p.length - 3) add("c:" + p.substring(i, i + 3), 0.2f * k)
        }
        for (i in 0 until w.size - 1) add("b:${stem(w[i])}_${stem(w[i + 1])}", 0.6f)

        val keys = m.keys.sorted().toIntArray()
        val vals = FloatArray(keys.size) { m[keys[it]]!! }
        var norm = 0f
        for (x in vals) norm += x * x
        norm = kotlin.math.sqrt(norm)
        if (norm > 0) for (i in vals.indices) vals[i] /= norm
        return Vec(keys, vals)
    }

    /** Dažni žodžiai – mažiau svarbūs prasmei. */
    val common = setOf(
        "kas", "yra", "ar", "koks", "kokia", "kokie", "kokios", "kaip", "kur", "kada", "kiek", "kodel",
        "mano", "tavo", "tu", "as", "man", "tau", "ir", "o", "bet", "kad", "is", "i", "su", "apie",
        "ka", "kuo", "buvo", "bus", "tai", "cia", "jis", "ji", "jie", "jos", "the", "a", "is", "of",
    )

    private val endings = listOf(
        "iuose", "uose", "iose", "iosios", "osios", "ieji", "oji", "ojo", "oje", "ajai", "iams", "iems", "iais", "ioms", "iaus", "iai", "ais", "ams", "ems",
        "oms", "ose", "ios", "ius", "iui", "iuj", "ies", "aus", "ens", "ers", "iu", "ys", "is", "as", "us", "es", "os", "ai", "ei", "ui",
        "ia", "io", "iu", "ji", "je", "ja", "a", "e", "o", "u", "i", "y", "s",
    )

    /** Lietuviška žodžio šaknis: „kompiuteriai“, „kompiuteris“ -> „kompiuter“. */
    fun stem(w: String): String {
        if (w.length <= 4) return w
        for (e in endings) if (w.endsWith(e) && w.length - e.length >= 3) return w.dropLast(e.length)
        return w
    }

    /** Prasminiai žodžiai (be dažnų), kaip šaknys. */
    fun contentStems(s: String): Set<String> = words(s).filter { it !in common }.map { stem(it) }.toSet()

    private val swap = mapOf(
        "mano" to "tavo", "aš" to "tu", "as" to "tu", "man" to "tau", "mane" to "tave",
        "manęs" to "tavęs", "manimi" to "tavimi", "manyje" to "tavyje", "esu" to "esi",
        "mėgstu" to "mėgsti", "megstu" to "megsti", "turiu" to "turi", "gyvenu" to "gyveni",
        "mokausi" to "mokaisi", "noriu" to "nori", "einu" to "eini", "žaidžiu" to "žaidi",
        "domiuosi" to "domiesi", "galiu" to "gali", "moku" to "moki", "dirbu" to "dirbi",
        "lankau" to "lankai", "vadinuosi" to "vadiniesi", "mano." to "tavo.",
    )

    /** „Mano vardas yra Tomas“ -> „Tavo vardas yra Tomas“ */
    fun swapPerson(s: String): String {
        val out = s.split(' ').joinToString(" ") { tok ->
            if (tok.isEmpty()) return@joinToString tok
            val core = tok.trimEnd('.', ',', '!', '?', ':')
            val tail = tok.substring(core.length)
            val rep = swap[core.lowercase()] ?: return@joinToString tok
            val fixed = if (core.first().isUpperCase()) rep.replaceFirstChar { it.uppercase() } else rep
            fixed + tail
        }
        return out.replaceFirstChar { it.uppercase() }
    }

    /** Sakinių skaidymas (interneto tekstams). */
    fun sentences(text: String): List<String> =
        text.replace(Regex("\\s+"), " ")
            .split(Regex("(?<=[.!?])\\s+(?=[A-ZĄČĘĖĮŠŲŪŽ0-9\"„(])"))
            .map { it.trim() }
            .filter { it.length in 25..400 }

    private val questionWords = setOf(
        "kas", "kodel", "kaip", "kur", "kada", "kiek", "koks", "kokia", "kokie", "kokios",
        "kuris", "kuri", "ar", "kieno", "kuo", "ka", "kam", "kokiu", "keli", "kelios",
        "what", "who", "why", "how", "where", "when", "which"
    )

    private val fillers = listOf(
        "ar gali man pasakyti", "ar gali pasakyti", "gal gali pasakyti", "ar galetum pasakyti", "ar gali", "gal gali",
        "ar galetum", "ar zinai", "gal zinai", "pasakyk man", "pasakyk", "sakyk", "prasau", "noreciau suzinoti",
        "noriu suzinoti", "man idomu", "idomu", "klausyk", "ei", "nu", "o", "tai", "beje", "gerai o", "okey", "ok",
    )

    /** „Ar gali pasakyti, kokia Lietuvos sostinė?“ -> „kokia lietuvos sostine“ */
    fun stripFillers(s: String): String {
        var t = normalize(s)
        var changed = true
        while (changed) {
            changed = false
            for (f in fillers) if (t.startsWith("$f ")) { t = t.removePrefix("$f ").trim(); changed = true }
        }
        return t.replace(" prasau", "").trim()
    }

    fun isQuestion(s: String): Boolean =
        s.trim().endsWith("?") || words(s).firstOrNull() in questionWords ||
            words(stripFillers(s)).firstOrNull() in questionWords
}
