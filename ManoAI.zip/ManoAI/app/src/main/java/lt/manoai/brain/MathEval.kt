package lt.manoai.brain

/** Paprastas skaičiuotuvas: 2+2, (3+4)*5, 2^10, 10/4 ... */
object MathEval {
    private val exprRegex = Regex("""[-+*/^().,\d\s×x÷:]{3,}""")

    fun tryAnswer(input: String): String? {
        val candidate = exprRegex.findAll(input).map { it.value.trim() }
            .filter { it.any(Char::isDigit) && it.any { c -> c in "+-*/^×x÷:" } }
            .maxByOrNull { it.length } ?: return null
        val expr = candidate.replace('×', '*').replace('x', '*').replace('÷', '/')
            .replace(':', '/').replace(',', '.').replace(" ", "")
        if (expr.count { it.isDigit() } == 0) return null
        return try {
            val r = Parser(expr).parse()
            if (r.isNaN() || r.isInfinite()) "Negaliu to apskaičiuoti (dalyba iš nulio?)."
            else "$candidate = ${format(r)}"
        } catch (e: Exception) {
            null
        }
    }

    private fun format(d: Double): String =
        if (d == Math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString()
        else "%.6f".format(d).trimEnd('0').trimEnd('.', ',')

    private class Parser(val s: String) {
        var p = 0
        fun parse(): Double { val v = expr(); if (p != s.length) error("liko"); return v }
        fun expr(): Double {
            var v = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) { val op = s[p++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = pow()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) { val op = s[p++]; val r = pow(); v = if (op == '*') v * r else v / r }
            return v
        }
        fun pow(): Double {
            val b = unary()
            if (p < s.length && s[p] == '^') { p++; return Math.pow(b, pow()) }
            return b
        }
        fun unary(): Double = if (p < s.length && s[p] == '-') { p++; -unary() } else atom()
        fun atom(): Double {
            if (p < s.length && s[p] == '(') { p++; val v = expr(); if (s.getOrNull(p) != ')') error(")"); p++; return v }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) error("skaičius")
            return s.substring(st, p).toDouble()
        }
    }
}
