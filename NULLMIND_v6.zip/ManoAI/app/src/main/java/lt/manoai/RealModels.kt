package lt.manoai

import lt.manoai.brain.Brain
import lt.manoai.brain.Kind
import lt.manoai.brain.Page
import lt.manoai.brain.Settings
import lt.manoai.brain.Text
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Ką AI žino apie tave – perduodama tikram modeliui kaip kontekstas (RAG). */
object Prompt {
    fun build(brain: Brain, s: Settings, query: String): String = buildString {
        if (s.systemPrompt.isNotBlank()) append(s.systemPrompt.trim()) else {
            append("Tu esi ${s.botName} – asmeninis asistentas. Atsakyk lietuviškai, aiškiai ir draugiškai.")
        }
        append("\nŠiandien: ${java.time.LocalDate.now()}.")
        if (s.userName.isNotBlank()) append(" Vartotojo vardas: ${s.userName}.")
        if (!s.useMemoryContext) return@buildString

        // Faktai, kuriuos vartotojas išmokė
        val facts = brain.items.filter { it.kind == Kind.FACT && it.source == "tu" }
            .map { it.answers.first() }
        if (facts.isNotEmpty()) {
            append("\n\nKą žinai apie vartotoją:\n")
            facts.take(40).forEach { append("- ").append(it).append('\n') }
        }
        // Su klausimu susiję išmokti dalykai (iš teksto, interneto, pamokymų)
        val related = brain.similar(query, 0.15f).take(8)
            .map { it.first }.filter { it.source != "tu" }
            .flatMap { if (it.kind == Kind.REPLY) it.answers else it.patterns }
        if (related.isNotEmpty()) {
            append("\nSusijusios žinios, kurių tave išmokė vartotojas:\n")
            related.take(8).forEach { append("- ").append(it.take(300)).append('\n') }
        }
    }
}

/** Tikras modelis internetu (OpenAI-suderinamas API: Gemini, OpenAI, Groq, OpenRouter, Ollama, LM Studio). */
class OnlineModel(private val web: WebTools) {
    /** Grąžina (atsakymas, šaltiniai). */
    fun ask(brain: Brain, s: Settings, history: List<Pair<Boolean, String>>, query: String): Pair<String, List<String>> {
        val ok = s.apiEndpoint.startsWith("https://") || (s.allowHttp && s.apiEndpoint.startsWith("http://"))
        require(ok) { "API adresas turi prasidėti https:// (http:// – tik įjungus 🛠)" }
        if (s.apiKey.isBlank() && !s.apiEndpoint.startsWith("http://"))
            error("Įvesk API raktą (⚙ nustatymai). Nemokamą gausi: aistudio.google.com")

        val sources = mutableListOf<String>()
        val sys = StringBuilder(Prompt.build(brain, s, query))

        // Internetas: jei įjungtas, pridedam šviežią informaciją
        if (s.webEnabled && web.online() && Text.isQuestion(query)) {
            runCatching {
                val pages = ArrayList<Page>()
                web.wiki(query)?.let { pages += it }
                web.search(query).take(s.maxPages).forEach { r -> (web.read(r.url) ?: r).let { pages += it } }
                if (pages.isNotEmpty()) {
                    sys.append("\n\nŠviežia informacija iš interneto (naudok, jei aktualu):\n")
                    pages.take(s.maxPages).forEach { p ->
                        sys.append("[${p.url}] ").append(p.text.take(s.maxPageChars / s.maxPages.coerceAtLeast(1))).append('\n')
                        sources += p.url
                    }
                }
            }
        }

        val messages = JSONArray().put(msg("system", sys.toString()))
        history.takeLast(16).forEach { (fromUser, t) -> messages.put(msg(if (fromUser) "user" else "assistant", t)) }
        messages.put(msg("user", query))

        val body = JSONObject().put("model", s.apiModel).put("messages", messages).put("temperature", 0.8)
        val answer = post(s, body)
        return answer to sources.distinct()
    }

    private fun msg(role: String, content: String) = JSONObject().put("role", role).put("content", content)

    private fun post(s: Settings, body: JSONObject): String {
        val conn = URL(s.apiEndpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000; conn.readTimeout = 90_000; conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (s.apiKey.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer ${s.apiKey}")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) error("Serverio klaida $code: ${text.take(300)}")
            return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally { conn.disconnect() }
    }
}
