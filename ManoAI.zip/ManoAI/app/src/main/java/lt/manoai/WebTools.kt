package lt.manoai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import lt.manoai.brain.Page
import lt.manoai.brain.SearchProvider
import lt.manoai.brain.Settings
import lt.manoai.brain.WebSource
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * AI prieiga prie interneto: Wikipedia, paieška ir puslapių skaitymas.
 * Visi filtrai (blokuojamos / leidžiamos svetainės, SafeSearch) taikomi čia.
 * Funkcijos blokuojančios – kviečiamos iš fono gijos.
 */
class WebTools(private val context: Context, private val settings: () -> Settings) : WebSource {
    private val ua = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Mobile Safari/537.36"

    override fun online(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ---------- Wikipedia ----------

    override fun wiki(query: String): Page? {
        val s = settings()
        val langs = if (s.wikiLang == "en") listOf("en") else listOf(s.wikiLang, "en")
        for (lang in langs) {
            val base = "https://$lang.wikipedia.org"
            if (isBlocked("$base/", s)) continue
            val found = json("$base/w/api.php?action=query&list=search&srlimit=1&format=json&utf8=1&srsearch=${enc(query)}")
                .optJSONObject("query")?.optJSONArray("search")?.optJSONObject(0) ?: continue
            val title = found.getString("title")
            val pages = json("$base/w/api.php?action=query&prop=extracts&explaintext=1&format=json&redirects=1&titles=${enc(title)}")
                .optJSONObject("query")?.optJSONObject("pages") ?: continue
            val page = pages.optJSONObject(pages.keys().next()) ?: continue
            val text = page.optString("extract").substringBefore("\n== Šaltiniai").substringBefore("\n== References")
            if (text.isBlank()) continue
            return Page(title, "$base/wiki/${enc(title.replace(' ', '_'))}", text.take(s.maxPageChars * 2))
        }
        return null
    }

    // ---------- Paieška ----------

    override fun search(query: String): List<Page> {
        val s = settings()
        val raw = when (s.searchProvider) {
            SearchProvider.DUCKDUCKGO -> duckDuckGo(query, s)
            SearchProvider.BRAVE -> brave(query, s)
            SearchProvider.SEARXNG -> searx(query, s)
        }
        return raw.filter { !isBlocked(it.url, s) }.distinctBy { it.url }.take(8)
    }

    private fun duckDuckGo(q: String, s: Settings): List<Page> {
        val kp = when (s.safeSearch) { 0 -> "-2"; 2 -> "1"; else -> "-1" }
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/")
            .data("q", q).data("kp", kp).userAgent(ua).timeout(15_000).post()
        return doc.select("div.result").mapNotNull { el ->
            val a = el.selectFirst("a.result__a") ?: return@mapNotNull null
            var href = a.attr("href")
            Regex("uddg=([^&]+)").find(href)?.let { href = URLDecoder.decode(it.groupValues[1], "UTF-8") }
            if (!href.startsWith("http")) return@mapNotNull null
            Page(a.text(), href, el.selectFirst(".result__snippet")?.text().orEmpty())
        }
    }

    private fun brave(q: String, s: Settings): List<Page> {
        require(s.searchKey.isNotBlank()) { "Brave paieškai reikia API rakto (🛠 kūrėjo meniu)" }
        val safe = when (s.safeSearch) { 0 -> "off"; 2 -> "strict"; else -> "moderate" }
        val body = Jsoup.connect("https://api.search.brave.com/res/v1/web/search?q=${enc(q)}&count=10&safesearch=$safe")
            .ignoreContentType(true).timeout(15_000)
            .header("Accept", "application/json").header("X-Subscription-Token", s.searchKey)
            .execute().body()
        val arr = JSONObject(body).optJSONObject("web")?.optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Page(o.optString("title"), o.optString("url"), Jsoup.parse(o.optString("description")).text())
        }
    }

    private fun searx(q: String, s: Settings): List<Page> {
        require(s.searxUrl.isNotBlank()) { "Įvesk SearXNG adresą (🛠 kūrėjo meniu)" }
        checkScheme(s.searxUrl, s)
        val arr = json(s.searxUrl.trimEnd('/') + "/search?q=${enc(q)}&format=json&safesearch=${s.safeSearch}")
            .optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Page(o.optString("title"), o.optString("url"), o.optString("content"))
        }
    }

    // ---------- Puslapio skaitymas ----------

    override fun read(url: String): Page? {
        val s = settings()
        checkScheme(url, s)
        if (isBlocked(url, s)) return null
        val doc = Jsoup.connect(url).userAgent(ua).timeout(20_000).followRedirects(true).get()
        doc.select("script, style, noscript, nav, footer, header, aside, form, iframe").remove()
        // Pastraipos duoda švaresnį tekstą nei visas puslapis
        val paragraphs = doc.select("p, li").map { it.text() }.filter { it.length > 40 }
        val text = if (paragraphs.size >= 3) paragraphs.joinToString(" ") else doc.body()?.text().orEmpty()
        return Page(doc.title(), url, text.take(s.maxPageChars))
    }

    // ---------- Filtrai ----------

    fun isBlocked(url: String, s: Settings): Boolean {
        val host = runCatching { URI(url).host?.lowercase()?.removePrefix("www.") }.getOrNull() ?: return true
        fun list(v: String) = v.split(',', ' ', '\n', ';').map { it.trim().lowercase().removePrefix("www.") }.filter { it.isNotEmpty() }
        val allowed = list(s.allowedDomains)
        if (allowed.isNotEmpty() && allowed.none { host == it || host.endsWith(".$it") }) return true
        return list(s.blockedDomains).any { host == it || host.endsWith(".$it") }
    }

    private fun checkScheme(url: String, s: Settings) {
        val ok = url.startsWith("https://") || (s.allowHttp && url.startsWith("http://"))
        require(ok) { "Leidžiami tik https:// adresai (http:// galima įjungti 🛠 kūrėjo meniu)" }
    }

    private fun json(url: String): JSONObject =
        JSONObject(Jsoup.connect(url).ignoreContentType(true).userAgent(ua).timeout(15_000).execute().body())

    private fun enc(q: String) = URLEncoder.encode(q, "UTF-8")
}
