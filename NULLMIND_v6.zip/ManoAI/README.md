# NULLMIND – asmeninis AI Android telefonui

Du varikliai, perjungiami ⚙ nustatymuose:
- **Tikras modelis** (numatytas): supranta temas ir logiškai kalba (per nemokamą Gemini ar kitą OpenAI-suderinamą API). Tai, ką jį išmokai, perduodama kaip kontekstas, tad jis žino ir tavo dalykus. Naudoja internetą.
- **Savas (nuo nulio)**: tavo paties parašytas modelis (384 neuronų, iki 512; mokymas su momentum), mokosi tik iš tavęs (Q&A poromis). Atrenka išmoktus atsakymus – nekuria naujų sakinių.

Jokių filtrų nepridėta. Tikras modelis turi savo įgimtą elgesį, kurio pašalinti negalima.

## Tikro modelio sąranka
1. Eik į **aistudio.google.com** → **Get API key** → nukopijuok (nemokama).
2. Programėlėje ⚙ → **Variklis: Tikras modelis** → įklijuok raktą → Išsaugoti.
3. Klausk ko nori – supras ir atsakys logiškai.
Veikia ir kiti API (OpenRouter, Groq, arba tavo Ollama/LM Studio serveris – ⚙ pakeisk adresą ir modelį).

## Kaip veikia AI smegenys
- **Neuroninis tinklas** (`Brain.kt`): tekstas → požymiai → paslėptas sluoksnis (48 neuronai, tanh) → softmax. Mokosi gradientiniu nusileidimu (backpropagation) tiesiai telefone.
- **Teksto supratimas** (`Text.kt`): supranta lietuviškas galūnes („kompiuteris“ = „kompiuteriai“), rašymą be nosinių („aciu“ = „ačiū“) ir rašybos klaidas.
- **Pradinės žinios** (`StarterData.kt`): pasisveikinimai, laikas, data, pagalba ir kt., kad AI suprastų tave nuo pirmos dienos. Gali jas keisti.
- **Stiliaus generatorius** (`Markov.kt`): mokosi, kaip tu rašai.
- **Skaičiuotuvas** (`MathEval.kt`).
- **Asistentas** (`Assistant.kt`): sujungia viską (filtrai → mokymasis → atmintis → tinklas → internetas → paklausia tavęs).

## 📚 Mokymo centras (mygtukas viršuje)
- **Įkelti .txt failą**: bet kokio dydžio, be ribų
- **Įklijuoti tekstą**: eilutės `klausimas | variantas => atsakymas | kitas atsakymas`, `Įsimink: …` arba bet koks paprastas tekstas (sakiniai tampa faktais)
- **Eksportuoti žinias**: visos AI žinios į .txt failą. Jį gali taisyti, papildyti ir vėl įkelti

## Užduotys
`15% nuo 240`, `šaknis iš 144`, `5 km į m`, `30 c į f`, `kiek dienų iki kalėdų`, `kokia data bus po 10 dienų`, `mesk kauliuką`, `mesk monetą`, `sugalvok skaičių nuo 1 iki 10`, `Išrink: pica ar blynai`, `Užrašyk: …`, `mano užrašai`, `Sutrumpink: …`, `daugiau` (po atsakymo iš interneto)

## Kaip mokyti
| Parašyk | Kas vyksta |
|---|---|
| **`Išmok: juodosios skylės`** | AI pats ieško internete (Wikipedia + paieška), skaito puslapius ir išsaugo faktus. Vėliau atsako ir be interneto |
| `Mano mėgstamiausia spalva yra mėlyna` | Įsimena faktą apie tave. Paklausk „kokia mano mėgstamiausia spalva?“ |
| `Įsimink: …` | Įsimena bet ką |
| `Kai sakau X, atsakyk Y` | Išmoksta konkretų atsakymą |
| 👍 / 👎 po atsakymu | 👍 sustiprina, 👎: AI paklaus, kaip turėjo atsakyti |
| `Teisingai: …` | Pataiso paskutinį atsakymą |
| Kai AI nežino | Pats paieško internete arba paklaus tavęs ir išmoks |
| `/web …` arba `Ieškok: …` | Paieška internete |
| Nuoroda `https://…` | Perskaito puslapį ir pasako esmę |
| `Pamiršk: …` | Ištrina |
| `/kurk` | Sugeneruoja tekstą tavo stiliumi |
| `ką žinai apie mane` | Parodo, ką apie tave žino |
| Daug eilučių `klausimas \| kitas klausimas => atsakymas \| kitas atsakymas` | Išmoksta visą sąrašą vienu kartu |

Pirmą kartą paleidus, AI susipažins su tavimi: paklaus vardo ir pomėgių.

🧠 mygtukas viršuje rodo visas AI žinias. Jas gali peržiūrėti, ieškoti ir ištrinti.

## 🛠 Kūrėjo meniu (7 kartus paspausk AI vardą viršuje)
- **Apsaugos**: ekrano nuotraukos, http://
- **Mokymasis**: ką mokytis automatiškai, mokymosi greitis, epochos, užtikrintumo riba, neuroninio tinklo svoris, neuronų skaičius, „Pertreniruoti“, „Kurti iš naujo“
- **Filtrai**: draudžiamos temos, draudžiami žodžiai (→ ***), atsisakymo tekstas, „nemokyti to, kas filtruose“
- **Internetas**: Wikipedia kalba, paieška (DuckDuckGo / Brave / SearXNG), SafeSearch, blokuojamos ir leidžiamos svetainės, kiek skaityti
- **Testavimas**: debug režimas (tikimybės), modelio būsena, ištrinti viską

⚙: tavo vardas, AI vardas, **PIN kodas** programėlei atidaryti.

## Saugumas
Visos žinios, pokalbiai ir nustatymai telefone užšifruoti (AES-256-GCM, raktas Android Keystore). Be interneto AI veikia pilnai, išskyrus paiešką.

## Ko tikėtis
Tai tikras, tavo paties AI, bet mažas. Jis nekurs ilgų tekstų kaip ChatGPT: atsako tuo, ką išmoko iš tavęs ir iš interneto. Kuo daugiau mokysi, tuo protingesnis bus.

## Kaip paleisti
**Su kompiuteriu:** Android Studio (developer.android.com/studio) → File → Open → `ManoAI` → ▶ Run.

**Be kompiuterio (per GitHub):**
1. github.com → susikurk paskyrą → New repository.
2. Įkelk visus failus (**įskaitant aplanką `.github`**).
3. Skirtukas **Actions** → palauk ✅ (5–10 min.) → atsisiųsk **ManoAI-apk** → įdiek `app-debug.apk`.
