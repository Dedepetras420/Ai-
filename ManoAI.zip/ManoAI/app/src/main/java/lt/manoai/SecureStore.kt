package lt.manoai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Viskas, kas saugoma telefone (pokalbiai, AI atmintis, API raktas),
 * šifruojama AES-256-GCM. Raktas laikomas Android Keystore – jo negalima
 * ištraukti iš telefono, net turint prieigą prie failų.
 */
class SecureStore(context: Context) {
    private val dir = context.filesDir

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        return c.iv + c.doFinal(plain) // 12 baitų IV + užšifruoti duomenys
    }

    private fun decrypt(data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, data, 0, 12))
        return c.doFinal(data, 12, data.size - 12)
    }

    fun write(name: String, text: String) {
        val tmp = File(dir, "$name.tmp")
        tmp.writeBytes(encrypt(text.toByteArray(Charsets.UTF_8)))
        tmp.renameTo(File(dir, "$name.bin"))
    }

    fun read(name: String): String? {
        val f = File(dir, "$name.bin")
        if (!f.exists()) return null
        return try {
            String(decrypt(f.readBytes()), Charsets.UTF_8)
        } catch (e: Exception) {
            null // sugadintas failas arba pasikeitęs raktas
        }
    }

    fun writeBytes(name: String, bytes: ByteArray) {
        val tmp = File(dir, "$name.tmp")
        tmp.writeBytes(encrypt(bytes))
        tmp.renameTo(File(dir, "$name.bin"))
    }

    fun readBytes(name: String): ByteArray? {
        val f = File(dir, "$name.bin")
        if (!f.exists()) return null
        return try { decrypt(f.readBytes()) } catch (e: Exception) { null }
    }

    fun delete(name: String) {
        File(dir, "$name.bin").delete()
    }

    companion object {
        private const val ALIAS = "manoai_master_key"
    }
}
