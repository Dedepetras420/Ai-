package lt.manoai

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import lt.manoai.brain.Assistant
import lt.manoai.brain.Brain
import lt.manoai.brain.Item
import lt.manoai.brain.Reply
import lt.manoai.brain.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

data class ChatMessage(
    val text: String,
    val fromUser: Boolean,
    val label: String = "",
    val itemId: Long? = null,
    val query: String = "",
    val sources: List<String> = emptyList(),
    val rated: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().put("t", text).put("u", fromUser).put("l", label)
        .put("i", itemId ?: -1L).put("q", query).put("s", JSONArray(sources)).put("r", rated)

    companion object {
        fun fromJson(o: JSONObject) = ChatMessage(
            o.getString("t"), o.getBoolean("u"), o.optString("l"),
            o.optLong("i", -1L).takeIf { it >= 0 }, o.optString("q"),
            o.optJSONArray("s")?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList(),
            o.optBoolean("r"),
        )

        fun of(r: Reply) = ChatMessage(r.text, false, r.label, r.itemId, r.query, r.sources)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SecureStore(app)
    // Visi darbai su modeliu – vienoje gijoje (modelis nėra daugiagijis)
    private val brainThread = Dispatchers.IO.limitedParallelism(1)

    val messages = mutableStateListOf<ChatMessage>()
    var settings by mutableStateOf(Settings()); private set
    var busy by mutableStateOf(true); private set
    var status by mutableStateOf("Kraunama…"); private set
    var unlocked by mutableStateOf(false); private set
    var knowledgeVersion by mutableStateOf(0); private set  // UI atsinaujinimui

    private lateinit var assistant: Assistant
    private val web = WebTools(app) { settings }

    init {
        viewModelScope.launch(brainThread) {
            val s = Settings.deserialize(store.read("settings"))
            val brain = store.readBytes("brain")?.let { runCatching { Brain.load(it) }.getOrNull() }
            val chat = store.read("chat")?.let { runCatching { JSONArray(it) }.getOrNull() }
            withContext(Dispatchers.Main) {
                settings = s
                unlocked = s.pinHash.isBlank()
                chat?.let { a -> for (i in 0 until a.length()) messages += ChatMessage.fromJson(a.getJSONObject(i)) }
            }
            if (brain != null) {
                assistant = Assistant(brain, s, web)
                hookStatus()
                // Nauja programėlės versija su naujomis pradinėmis žiniomis – pridedam jas
                if (s.starterVersion < lt.manoai.brain.StarterData.VERSION) {
                    val n = assistant.upgradeStarter { e, _ -> status = "🧠 Atnaujinamos žinios: $e/${s.epochs}" }
                    saveBrain(); syncSettings()
                    status = "✅ Pridėta $n naujų žinių"
                }
                if (messages.isEmpty()) addBot(assistant.welcome())
                status = "Žinių: ${brain.items.size}"
            } else {
                createBrain(s)
            }
            busy = false
        }
    }

    private fun hookStatus() { assistant.status = { status = it } }

    /** Naujas modelis nuo nulio + pradinis apmokymas. */
    private suspend fun createBrain(s: Settings) {
        val brain = Brain(hidden = s.hidden.coerceIn(8, 256))
        assistant = Assistant(brain, s, web)
        hookStatus()
        status = "🧠 Mokausi pradinių žinių…"
        assistant.pretrain { e, loss -> status = "🧠 Pradinis mokymas: epocha $e/${s.epochs}, klaida %.3f".format(loss) }
        saveBrain()
        val hello = assistant.welcome()
        withContext(Dispatchers.Main) { messages.clear(); messages += ChatMessage.of(hello); saveChat() }
        status = "Modelis paruoštas (${brain.items.size} žinių)"
    }

    private fun addBot(r: Reply) {
        viewModelScope.launch(Dispatchers.Main) { messages += ChatMessage.of(r); saveChat() }
    }

    // ---------- Pokalbis ----------

    fun send(input: String) {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        messages += ChatMessage(text, true)
        busy = true
        viewModelScope.launch(brainThread) {
            val reply = try {
                assistant.reply(text)
            } catch (e: Throwable) {
                Reply("Klaida: ${e.message}" + if (settings.debug) "\n\n" + e.stackTraceToString().take(1500) else "", "klaida")
            }
            syncSettings()
            saveBrain()
            withContext(Dispatchers.Main) {
                messages += ChatMessage.of(reply)
                busy = false
                status = "Žinių: ${assistant.brain.items.size}"
                knowledgeVersion++
                saveChat()
            }
        }
    }

    /** 👍 / 👎 po atsakymu. */
    fun rate(index: Int, good: Boolean) {
        val m = messages.getOrNull(index) ?: return
        val id = m.itemId ?: return
        messages[index] = m.copy(rated = true)
        viewModelScope.launch(brainThread) {
            val follow = assistant.feedback(id, m.query, good)
            saveBrain()
            withContext(Dispatchers.Main) {
                status = if (good) "👍 Sustiprinau šį atsakymą" else "👎 Pasakyk, kaip turėjau atsakyti"
                follow?.let { messages += ChatMessage.of(it) }
                saveChat()
            }
        }
    }

    // Asistentas gali pakeisti nustatymus (pvz., išmokęs tavo vardą)
    private suspend fun syncSettings() {
        if (assistant.settings != settings) {
            val s = assistant.settings
            store.write("settings", s.serialize())
            withContext(Dispatchers.Main) { settings = s }
        }
    }

    // ---------- Nustatymai ----------

    fun updateSettings(s: Settings) {
        settings = s
        viewModelScope.launch(brainThread) {
            store.write("settings", s.serialize())
            if (::assistant.isInitialized) { assistant.settings = s; assistant.applySettings() }
        }
    }

    // ---------- PIN ----------

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        if (pin.isBlank()) { updateSettings(settings.copy(pinHash = "")); return }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        updateSettings(settings.copy(pinHash = "$salt:${hash(pin, salt)}"))
    }

    fun unlock(pin: String): Boolean {
        val (salt, h) = settings.pinHash.split(':').let { (it.getOrNull(0) ?: "") to (it.getOrNull(1) ?: "") }
        unlocked = hash(pin, salt) == h
        return unlocked
    }

    // ---------- Žinios ----------

    fun knowledge(filter: String): List<Item> {
        if (!::assistant.isInitialized) return emptyList()
        val all = assistant.brain.items.toList().reversed()
        if (filter.isBlank()) return all.take(300)
        val f = lt.manoai.brain.Text.normalize(filter)
        return all.filter { i -> (i.patterns + i.answers).any { lt.manoai.brain.Text.normalize(it).contains(f) } }.take(300)
    }

    fun forget(item: Item) {
        viewModelScope.launch(brainThread) {
            assistant.brain.remove(item); saveBrain()
            withContext(Dispatchers.Main) { knowledgeVersion++ }
        }
    }

    fun stats(): String {
        if (!::assistant.isInitialized) return ""
        val b = assistant.brain
        return "Žinių: ${b.items.size} (tavo: ${b.items.count { it.source == "tu" }}, " +
            "iš interneto: ${b.items.count { it.source.startsWith("internetas") }}, pradinių: ${b.items.count { it.source == "pradinis" }})\n" +
            "Neuronų: ${b.hidden}, požymių: ${b.dim}\n" +
            "Mokymosi žingsnių: ${b.trainedSteps}, paskutinė klaida: %.3f\n".format(b.lastLoss) +
            "Stiliaus generatorius: ${b.markov.size} derinių"
    }

    // ---------- Kūrėjo įrankiai ----------

    private var taps = 0
    private var lastTap = 0L

    fun onTitleTap() {
        if (settings.devUnlocked) return
        val now = System.currentTimeMillis()
        taps = if (now - lastTap < 800) taps + 1 else 1
        lastTap = now
        when {
            taps >= 7 -> { updateSettings(settings.copy(devUnlocked = true)); status = "🛠 Kūrėjo režimas įjungtas" }
            taps >= 4 -> status = "Liko ${7 - taps} paspaudimai iki kūrėjo režimo"
        }
    }

    fun lockDev() { updateSettings(settings.copy(devUnlocked = false)); status = "Kūrėjo režimas išjungtas" }

    /** Pertreniruoja tinklą per visas žinias. */
    fun retrain() {
        busy = true
        viewModelScope.launch(brainThread) {
            val ep = settings.epochs
            assistant.brain.trainAll(ep) { e, loss -> status = "🧠 Treniruojama: $e/$ep, klaida %.3f".format(loss) }
            saveBrain()
            status = "✅ Pertreniruota. Klaida: %.3f".format(assistant.brain.lastLoss)
            busy = false
        }
    }

    /** Ištrina modelį ir sukuria naują nuo nulio (nustatymai lieka). */
    fun resetBrain() {
        busy = true
        viewModelScope.launch(brainThread) {
            val s = settings.copy(userName = "")
            store.write("settings", s.serialize())
            withContext(Dispatchers.Main) { settings = s }
            createBrain(s)
            withContext(Dispatchers.Main) { knowledgeVersion++ }
            busy = false
        }
    }

    fun clearChat() { messages.clear(); saveChat() }

    fun wipeAll() {
        busy = true
        viewModelScope.launch(brainThread) {
            listOf("chat", "brain", "settings").forEach { store.delete(it) }
            val s = Settings()
            withContext(Dispatchers.Main) { settings = s; unlocked = true }
            createBrain(s)
            busy = false
        }
    }

    fun debugDump(): String {
        val s = settings
        val masked = s.copy(pinHash = if (s.pinHash.isBlank()) "" else "(nustatytas)", searchKey = if (s.searchKey.isBlank()) "" else "(yra)")
        return stats() + "\n\n--- Nustatymai ---\n" + masked.serialize().lines().filter { !it.startsWith("#") }.sorted().joinToString("\n")
    }

    // ---------- Mokymo centras ----------

    /** Mokosi iš teksto (įklijuoto arba iš failo) – be ribų. */
    fun learnText(text: String) {
        if (text.isBlank() || busy) return
        busy = true
        messages += ChatMessage("📚 [Mokymas iš teksto: ${text.length} simbolių]", true)
        viewModelScope.launch(brainThread) {
            val r = try { assistant.learnText(text) } catch (e: Throwable) { Reply("Klaida: ${e.message}", "klaida") }
            saveBrain()
            withContext(Dispatchers.Main) {
                messages += ChatMessage.of(r); busy = false; knowledgeVersion++
                status = "Žinių: ${assistant.brain.items.size}"; saveChat()
            }
        }
    }

    fun importFile(uri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val text = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }.getOrElse { status = "Nepavyko perskaityti failo: ${it.message}"; return@launch }
            withContext(Dispatchers.Main) { learnText(text) }
        }
    }

    fun exportFile(uri: android.net.Uri) {
        viewModelScope.launch(brainThread) {
            val text = assistant.exportText()
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            }.onSuccess { status = "✅ Žinios eksportuotos (${text.lines().size} eilučių)" }
                .onFailure { status = "Nepavyko išsaugoti: ${it.message}" }
        }
    }

    // ---------- Išsaugojimas (užšifruota) ----------

    private fun saveBrain() { store.writeBytes("brain", assistant.brain.save()) }

    private fun saveChat() {
        val json = JSONArray().apply { messages.takeLast(300).forEach { put(it.toJson()) } }.toString()
        viewModelScope.launch(Dispatchers.IO) { store.write("chat", json) }
    }
}
