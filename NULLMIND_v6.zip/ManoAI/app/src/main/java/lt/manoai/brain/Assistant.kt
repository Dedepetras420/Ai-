package lt.manoai.brain

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/** Interneto šaltinis (Android dalyje – WebTools). */
interface WebSource {
    fun online(): Boolean
    fun wiki(query: String): Page?
    fun search(query: String): List<Page>
    fun read(url: String): Page?
}

data class Page(val title: String, val url: String, val text: String)

data class Reply(
    val text: String,
    val label: String,                 // iš kur atsakymas
    val itemId: Long? = null,          // kuriai žiniai galima duoti 👍/👎
    val query: String = "",
    val sources: List<String> = emptyList(),
)

/**
 * Tavo AI: sprendžia, kaip atsakyti, ir mokosi.
 * Tvarka: filtrai -> laukiami atsakymai -> komandos -> faktai apie tave ->
 *         skaičiuotuvas -> neuroninis tinklas -> internetas -> generatorius -> klausia tavęs.
 */
class Assistant(var brain: Brain, var settings: Settings, private val web: WebSource?) {
    private val rnd = Random.Default
    private var awaitingAnswerFor: String? = null
    private var onboarding = 0            // 1 – laukia vardo, 2 – laukia pomėgių
    private var lastQuery: String? = null
    private var lastItem: Item? = null
    var status: (String) -> Unit = {}

    init { applySettings() }

    fun applySettings() {
        brain.learningRate = settings.learningRate
        brain.nnWeight = settings.nnWeight
        brain.quickSteps = settings.quickSteps
        brain.markov.order = settings.markovOrder
    }

    /** Pirmas paleidimas: įkelia pradines žinias ir apmoko tinklą. */
    fun pretrain(onProgress: (Int, Float) -> Unit = { _, _ -> }) {
        for ((pats, ans) in StarterData.all()) brain.add(Kind.REPLY, pats, ans, "pradinis", train = false)
        brain.trainAll(settings.epochs, onProgress)
        settings = settings.copy(starterVersion = StarterData.VERSION)
    }

    /** Atnaujinimas: prideda naujas pradines žinias, NELIEČIANT to, ko išmokei pats. */
    fun upgradeStarter(onProgress: (Int, Float) -> Unit = { _, _ -> }): Int {
        val known = brain.items.flatMap { it.patterns }.map { Text.normalize(it) }.toSet()
        var added = 0
        for ((pats, ans) in StarterData.all()) {
            val fresh = pats.filter { Text.normalize(it) !in known }
            if (fresh.isEmpty()) continue
            brain.add(Kind.REPLY, fresh, ans, "pradinis", train = false); added++
        }
        if (added > 0) brain.trainAll(settings.epochs, onProgress)
        settings = settings.copy(starterVersion = StarterData.VERSION)
        return added
    }

    fun welcome(): Reply {
        return if (settings.userName.isBlank()) {
            onboarding = 1
            Reply("Labas! Aš esu ${settings.botName} – tavo asmeninis AI, parašytas nuo nulio. Mokausi iš mūsų pokalbių ir iš interneto.\n\nKuo tu vardu?", "sveikinimas")
        } else Reply(fill("Labas, {vardas}! Kuo galiu padėti?"), "sveikinimas")
    }

    // Pokalbio kontekstas
    private var pendingGuess: Pair<Item, String>? = null   // „Ar turėjai omeny…?“
    private var more: List<String> = emptyList()           // „papasakok daugiau“
    private var moreSources: List<String> = emptyList()

    /** Spėjimas: bando ir originalų tekstą, ir be užpildų („ar gali pasakyti…“). */
    private fun predictBest(text: String): Prediction? {
        val a = brain.predict(text)
        val stripped = Text.stripFillers(text)
        if (stripped.isEmpty() || stripped == Text.normalize(text)) return a
        val b = brain.predict(stripped)
        return listOfNotNull(a, b).maxByOrNull { it.confidence }
    }

    private fun answerFor(p: Prediction, query: String): Reply {
        lastItem = p.item
        return Reply(fill(p.item.answers.random(rnd)), label(p), p.item.id, query)
    }

    // =============================================================

    fun reply(input: String): Reply {
        val text = input.trim()
        if (text.isEmpty()) return Reply("", "")
        val norm = Text.normalize(text)

        // 1. Filtrai (tušti, kol pats jų neįrašysi)
        if (settings.filterInput && hitsTopic(norm)) return out(Reply(settings.refusalText, "filtras"))

        // 2. Pažintis
        if (onboarding == 1) return out(learnName(text))
        if (onboarding == 2) {
            onboarding = 0
            learnFact("Aš domiuosi: $text")
            return out(Reply(fill("Įsiminiau! Dabar tave šiek tiek pažįstu, {vardas}. 😊\n\nKai ko nors nežinosiu – paieškosiu internete arba paklausiu tavęs. Parašyk „kaip tave mokyti“, kad sužinotum visas komandas."), "pažintis"))
        }

        // 3. Atsakymas į „Ar turėjai omeny…?“
        pendingGuess?.let { (item, q) ->
            pendingGuess = null
            if (norm in YES) {
                brain.addPattern(item, q)          // išmoksta: tai reiškia tą patį
                lastItem = item
                return out(Reply(fill(item.answers.random(rnd)), "supratau 🧠 · išmokau", item.id, q))
            }
            if (norm in NO) {
                awaitingAnswerFor = q
                return out(Reply("Supratau. Tai kaip turėčiau atsakyti į „$q“? (arba „praleisk“)", "mokymasis"))
            }
        }

        // 4. Laukiam, kol išmokysi atsakymo
        awaitingAnswerFor?.let { q ->
            awaitingAnswerFor = null
            if (norm in SKIP) return out(Reply("Gerai, praleidžiam.", "mokymasis"))
            val isTask = Skills.tryAnswer(text) != null || MathEval.tryAnswer(text) != null
            if (!Text.isQuestion(text) && !isCommand(norm) && !isTask) {
                if (blockedForLearning(text)) return out(Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras"))
                val item = brain.teach(q, text, "tu")
                lastItem = item
                return out(Reply("Ačiū! Išmokau: į „$q“ atsakysiu „$text“.", "mokymasis 🧠"))
            }
        }

        // 5. „Papasakok daugiau“
        if (norm in MORE && more.isEmpty() && lastItem?.source?.startsWith("internetas") == true) {
            return out(Reply("Daugiau apie tai nieko neradau. Paklausk ko nors kito arba parašyk „Išmok: …“.", "internetas"))
        }
        if (norm in MORE && more.isNotEmpty()) {
            val next = more.take(settings.answerSentences); more = more.drop(settings.answerSentences)
            val tail = if (more.isNotEmpty()) "\n\n(Parašyk „daugiau“, jei nori dar.)" else ""
            return out(Reply(next.joinToString(" ") + tail, "internetas 🌐 · tęsinys", sources = moreSources))
        }

        // 6. Mokymas iš teksto / sąrašo (daug eilučių vienu kartu)
        if (norm.startsWith("mokykis")) command(text, norm)?.let { return out(it) }
        if (text.lines().count { it.isNotBlank() } >= 2) batchTeach(text)?.let { return out(it) }

        // 7. Komandos
        command(text, norm)?.let { return out(it) }

        if (settings.autoLearnStyle) brain.markov.train(text)

        // 8. Faktai apie tave („Mano ... yra ...“)
        if (settings.autoLearnFacts && isStatementAboutMe(norm, text)) {
            if (blockedForLearning(text)) return out(Reply("To neįsiminsiu – tai yra tavo filtruose.", "filtras"))
            val fact = learnFact(text)
            return out(Reply("Įsiminiau: ${fact.answers.first()}", "atmintis 🧠"))
        }

        // 9. Užduotys: skaičiavimai, datos, vienetai, kauliukas...
        Skills.tryAnswer(text)?.let { return out(Reply(it, "užduotis ✔")) }
        MathEval.tryAnswer(text)?.let { return out(Reply(it, "skaičiuotuvas")) }

        lastQuery = text

        // 10. Klausimas apie tave („koks mano vardas?“)
        aboutMe(text, norm)?.let { return out(it) }

        // 11. Neuroninis tinklas
        val pred = predictBest(text)
        // Apsauga nuo „drąsių klaidų": klausimas turi būti tikrai panašus į tai, ką žinau
        val related = pred != null && (pred.similarity >= 0.3f ||
            Text.contentStems(text).any { it in Text.contentStems(pred.item.patterns.joinToString(" ")) })
        if (pred != null && related && pred.confidence >= settings.threshold) {
            // Keli sakiniai vienoje žinutėje („Labas, kaip sekasi?“)
            multiPart(text, pred)?.let { return out(it) }
            return out(answerFor(pred, text))
        }
        multiPart(text, null)?.let { return out(it) }

        // 12. Nėra visai tikras – pasitikslina
        if (settings.clarify && pred != null && pred.confidence >= settings.threshold - 0.15f &&
            Text.contentStems(text).any { it in Text.contentStems(pred.item.patterns.joinToString(" ")) }
        ) {
            pendingGuess = pred.item to text
            val p = pred.item.patterns.first()
            return out(Reply("Ar turėjai omeny: „$p“? (taip / ne)", "patikslinimas · ${(pred.confidence * 100).toInt()}%"))
        }

        // 13. Internetas
        var webFail: String? = null
        if (settings.webEnabled && settings.webWhenUnknown && Text.isQuestion(text) && web != null) {
            if (!web.online()) webFail = "nėra interneto ryšio"
            else {
                webAnswer(text)?.let { return out(it) }
                webFail = "internete nieko tinkamo neradau${webFailReason()}"
            }
        }

        // 14. Generatorius
        if (settings.generator) {
            brain.markov.generate(text.split(" ").takeLast(2).joinToString(" "), 25, settings.genTemperature.toDouble())
                ?.let { return out(Reply(it, "generatorius")) }
        }

        // 15. Nežino – klausia tavęs
        lastItem = null
        if (settings.learnByAsking) {
            awaitingAnswerFor = text
            val why = webFail?.let { "\n(internete: $it)" } ?: ""
            val hint = if (pred != null && settings.debug) "\n(geriausias spėjimas: „${pred.item.patterns.first()}“, ${(pred.confidence * 100).toInt()}%)" else ""
            return out(Reply("Dar nežinau, ką atsakyti. 🤔 Kaip turėčiau atsakyti? Parašyk atsakymą, ir aš išmoksiu (arba „praleisk“).$why$hint", "nežino"))
        }
        return out(Reply("Nežinau. Gali mane išmokyti: „Kai sakau X, atsakyk Y“.", "nežino"))
    }

    /**
     * Tik mokymas ir komandos (kai atsakinėja tikras modelis).
     * Grąžina Reply, jei tai buvo mokymas/komanda; null, jei įprastas pokalbis.
     */
    fun learnOnly(text: String): Reply? {
        val t = text.trim(); if (t.isEmpty()) return null
        val n = Text.normalize(t)
        if (t.lines().count { it.isNotBlank() } >= 2) batchTeach(t)?.let { return out(it) }
        if (n.startsWith("mokykis")) command(t, n)?.let { return out(it) }
        command(t, n)?.let { if (isCommand(n) || urlRe.containsMatchIn(t)) return out(it) }
        if (settings.autoLearnFacts && isStatementAboutMe(n, t)) {
            val f = learnFact(t); return out(Reply("Įsiminiau: ${f.answers.first()}", "atmintis 🧠"))
        }
        return null
    }

    /** Kai žinutėje keli sakiniai – atsako į kiekvieną, kurį supranta. */
    private fun multiPart(text: String, whole: Prediction?): Reply? {
        val parts = text.split(Regex("""(?<=[.!?])\s+|,\s+|;\s*""")).map { it.trim(' ', '.', '!', ',') }.filter { it.length >= 2 }
        if (parts.size !in 2..4) return null
        val preds = parts.map { predictBest(it) }
        val good = preds.filterNotNull().filter { it.confidence >= settings.threshold }.distinctBy { it.item.id }
        if (good.size < 2) return null
        if (whole != null && whole.confidence >= good.maxOf { it.confidence }) return null
        lastItem = good.last().item
        return Reply(good.joinToString(" ") { fill(it.item.answers.random(rnd)) }, label(good.last()), good.last().item.id, text)
    }

    private companion object {
        val YES = setOf("taip", "jo", "aha", "tikrai", "yes", "taip taip", "jep", "tiksliai", "butent", "teisingai", "yep", "ja")
        val NO = setOf("ne", "nea", "no", "visai ne", "ne ne", "nu ne", "nope")
        val SKIP = setOf("praleisk", "nezinau", "nieko", "nesvarbu", "skip", "ne", "pamirsk", "nereikia")
        val MORE = setOf("daugiau", "papasakok daugiau", "dar", "tesk", "o daugiau", "dar daugiau", "ir", "ir kas toliau", "toliau", "placiau", "paaiskink placiau")
    }

    // ---------------- Komandos ----------------

    private val teachRe = Regex("""^kai\s+(sakau|rašau|rasau|klausiu|parašau|parasau)\s+(.+?),?\s+(atsakyk|sakyk|rašyk|rasyk)\s*:?\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val urlRe = Regex("""https?://\S+""")

    private fun after(text: String) = text.substringAfter(':', "").trim().ifEmpty { text.substringAfter(' ', "").trim() }

    private fun isCommand(n: String) = listOf("isimink", "ismok", "teisingai", "pamirsk", "ieskok", "web", "kurk", "uzrasyk", "sutrumpink", "mokykis").any { n.startsWith(it) }

    private fun command(text: String, n: String): Reply? {
        when {
            n.startsWith("uzrasyk") || n.startsWith("uzsirasyk") || n.startsWith("pasizymek") || n.startsWith("uzsirasyti") -> {
                val note = after(text)
                if (note.isEmpty()) return Reply("Ką užrašyti? Pvz.: „Užrašyk: nupirkti pieno“", "užrašai")
                brain.add(Kind.FACT, listOf(note), listOf(note), "užrašas", train = false)
                return Reply("📝 Užrašiau: $note", "užrašai")
            }
            n in setOf("mano uzrasai", "parodyk uzrasus", "uzrasai", "kas uzrasyta", "ka uzrasei") -> {
                val notes = brain.items.filter { it.source == "užrašas" }
                return Reply(if (notes.isEmpty()) "Užrašų nėra. Parašyk „Užrašyk: …“"
                else "📝 Tavo užrašai:\n" + notes.mapIndexed { i, it -> "${i + 1}. ${it.answers.first()}" }.joinToString("\n"), "užrašai")
            }
            n in setOf("istrink uzrasus", "isvalyk uzrasus", "pamirsk uzrasus") -> {
                val notes = brain.items.filter { it.source == "užrašas" }
                notes.forEach { brain.remove(it) }
                return Reply("🗑 Ištryniau ${notes.size} užrašus.", "užrašai")
            }
            n.startsWith("mokykis") || n.startsWith("ismok is teksto") || n.startsWith("ismok teksta") -> {
                val t = text.substringAfter(':', "").trim()
                if (t.isEmpty()) return Reply("Po dvitaškio įklijuok tekstą, pvz.: „Mokykis: …“ – arba naudok 📚 Mokymo centrą.", "mokymasis")
                return learnText(t)
            }
            n.startsWith("sutrumpink") || n.startsWith("santrauka") || n.startsWith("apibendrink") -> {
                val t = after(text)
                if (t.length < 80) return Reply("Įklijuok ilgesnį tekstą po dvitaškio, pvz.: „Sutrumpink: …“", "užduotis")
                return Reply(summarize(t, settings.answerSentences).ifEmpty { t.take(300) }, "santrauka ✔")
            }
            n.startsWith("isimink") -> {
                val f = after(text).ifEmpty { return Reply("Ką įsiminti? Pvz.: „Įsimink: mano mėgstamiausia spalva mėlyna“", "atmintis") }
                if (blockedForLearning(f)) return Reply("To neįsiminsiu – tai yra tavo filtruose.", "filtras")
                val item = learnFact(f)
                return Reply("Įsiminiau: ${item.answers.first()}", "atmintis 🧠")
            }
            n.startsWith("ismok") -> {
                val topic = text.substringAfter(':', text.drop(5)).trim()
                    .removePrefix("apie ").removePrefix("Apie ").trim()
                if (topic.isEmpty()) return Reply("Ką išmokti? Pvz.: „Išmok: juodosios skylės“", "mokymasis")
                return learnTopic(topic)
            }
            n.startsWith("teisingai") || n.startsWith("turejai atsakyti") -> {
                val ans = after(text)
                val q = lastQuery ?: return Reply("Nėra ką taisyti – pirma paklausk ko nors.", "mokymasis")
                if (ans.isEmpty()) return Reply("Parašyk: „Teisingai: tavo atsakymas“", "mokymasis")
                if (blockedForLearning(ans)) return Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras")
                lastItem?.let { brain.reinforce(it, false) }
                lastItem = brain.teach(q, ans, "tu")
                return Reply("Pataisiau! Į „$q“ dabar atsakysiu: „$ans“", "mokymasis 🧠")
            }
            n.startsWith("pamirsk") -> {
                val what = after(text)
                if (what.isEmpty()) return Reply("Ką pamiršti? Pvz.: „Pamiršk: mano mėgstamiausia spalva“", "atmintis")
                val hits = brain.similar(what, 0.6f).filter { it.first.source != "pradinis" }
                hits.forEach { brain.remove(it.first) }
                return Reply(if (hits.isEmpty()) "Nieko panašaus neradau." else "Pamiršau ${hits.size} dalykus.", "atmintis")
            }
            teachRe.matches(text) -> {
                val m = teachRe.find(text)!!
                val q = m.groupValues[2].trim('"', '„', '“', ' ')
                val a = m.groupValues[4].trim('"', '„', '“', ' ')
                if (blockedForLearning(q + " " + a)) return Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras")
                lastItem = brain.teach(q, a, "tu")
                return Reply("Išmokau! Kai parašysi „$q“, atsakysiu „$a“.", "mokymasis 🧠")
            }
            n.startsWith("web ") || n.startsWith("ieskok") || text.startsWith("/web") -> {
                val q = text.removePrefix("/").substringAfter(' ').substringAfter(':').trim()
                if (!canUseWeb()) return Reply("Internetas neprieinamas arba išjungtas nustatymuose.", "internetas")
                return webAnswer(q) ?: Reply("Internete nieko tinkamo neradau.${webFailReason()}", "internetas")
            }
            n.startsWith("kurk") || text.startsWith("/kurk") -> {
                val seed = text.removePrefix("/").substringAfter(' ', "").substringAfter(':').trim()
                return Reply(brain.markov.generate(seed, 40, settings.genTemperature.toDouble())
                    ?: "Dar per mažai išmokau tavo stiliaus – pasikalbėkim daugiau.", "generatorius")
            }
            urlRe.containsMatchIn(text) && canUseWeb() -> {
                val url = urlRe.find(text)!!.value
                val page = web!!.read(url) ?: return Reply("Nepavyko atidaryti puslapio.", "internetas")
                val top = summarize(page.text, settings.answerSentences + 1)
                return Reply(filterOut(top.ifEmpty { page.title }), "internetas 🌐", sources = listOf(url))
            }
        }
        return null
    }

    // ---------------- Mokymas iš sąrašo ----------------

    /**
     * Kiekviena eilutė – vienas pamokymas:
     *   labas | sveikas => Labas! | Sveikas!
     *   Kai sakau X, atsakyk Y
     *   Įsimink: faktas
     * Eilutės, prasidedančios #, – komentarai.
     */
    private fun batchTeach(text: String, minCount: Int = 2): Reply? {
        var replies = 0; var facts = 0; var skipped = 0
        val parsed = ArrayList<() -> Unit>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val n = Text.normalize(line)
            when {
                "=>" in line -> {
                    val (pats, ans) = StarterData.parse(line) ?: run { skipped++; null } ?: continue
                    if (blockedForLearning(line)) { skipped++; continue }
                    parsed += { brain.add(Kind.REPLY, pats, ans, "tu", train = false) }; replies++
                }
                teachRe.matches(line) -> {
                    val m = teachRe.find(line)!!
                    val q = m.groupValues[2].trim('"', '„', '“', ' '); val a = m.groupValues[4].trim('"', '„', '“', ' ')
                    if (blockedForLearning(line)) { skipped++; continue }
                    parsed += { brain.add(Kind.REPLY, listOf(q), listOf(a), "tu", train = false) }; replies++
                }
                n.startsWith("isimink") -> {
                    val f = after(line)
                    if (f.isEmpty() || blockedForLearning(f)) { skipped++; continue }
                    parsed += { learnFact(f) }; facts++
                }
                else -> skipped++
            }
        }
        if (replies + facts < minCount || replies + facts == 0) return null   // ne sąrašas – paprasta žinutė
        status("🧠 Mokausi ${replies + facts} dalykų…")
        parsed.forEach { it() }
        brain.trainAll(settings.epochs) { e, l -> status("🧠 Mokausi: epocha $e/${settings.epochs}, klaida %.3f".format(l)) }
        val extra = if (skipped > 0) "\n($skipped eilučių nesupratau arba jos filtruose)" else ""
        return Reply("📚 Išmokau ${replies} atsakymų ir ${facts} faktų!$extra", "mokymasis 🧠")
    }

    /**
     * Mokymasis iš bet kokio teksto (failo ar įklijuoto) – be ribų:
     *  - eilutės „klausimas => atsakymas“, „Kai sakau…“, „Įsimink:“ – išmokstami atsakymai;
     *  - visa kita (paprastas tekstas) – sakiniai tampa faktais, o stilius – generatoriui.
     */
    fun learnText(text: String): Reply {
        val lines = text.lines()
        val isTeach = { l: String -> val t = l.trim(); "=>" in t || teachRe.matches(t) || Text.normalize(t).startsWith("isimink") }
        val teach = lines.filter(isTeach)
        val prose = lines.filterNot { isTeach(it) || it.trim().startsWith("#") }.joinToString("\n")
        val parts = ArrayList<String>()
        if (teach.isNotEmpty()) batchTeach(teach.joinToString("\n"), 1)?.let { parts += it.text }

        if (prose.isNotBlank()) {
            status("📖 Skaitau tekstą…")
            val known = brain.items.flatMap { it.patterns }.map { Text.normalize(it) }.toHashSet()
            var added = 0
            val sentences = Text.sentences(prose).ifEmpty { prose.split('\n').map { it.trim() }.filter { it.length >= 15 } }
            for ((i, sent) in sentences.withIndex()) {
                if (blockedForLearning(sent)) continue
                val n = Text.normalize(sent)
                if (n in known) continue
                known += n
                brain.add(Kind.FACT, listOf(sent), listOf(sent), "tekstas", train = false); added++
                if (settings.autoLearnStyle) brain.markov.train(sent)
                if (i % 200 == 0) status("📖 Skaitau tekstą… $i/${sentences.size}")
            }
            parts += "📖 Iš teksto įsiminiau $added naujų faktų."
        }
        if (parts.isEmpty()) return Reply("Tekste neradau nieko, ko galėčiau išmokti.", "mokymasis")
        return Reply(parts.joinToString("\n") + "\n\nDabar gali manęs apie tai klausti.", "mokymasis 🧠")
    }

    /** Visos žinios tekstu – kad galėtum peržiūrėti, taisyti ar papildyti ir vėl įkelti. */
    fun exportText(): String = buildString {
        append("# ${settings.botName} – žinių eksportas\n")
        append("# Formatas: klausimas | kitas variantas => atsakymas | kitas atsakymas\n\n")
        for (it in brain.items) {
            fun clean(x: String) = x.replace("\n", "\\n").replace("|", "/").replace("=>", "->")
            when (it.kind) {
                Kind.REPLY -> append(it.patterns.joinToString(" | ", transform = ::clean))
                    .append(" => ").append(it.answers.joinToString(" | ", transform = ::clean)).append('\n')
                Kind.FACT -> if (it.source != "užrašas") append("Įsimink: ").append(clean(it.patterns.first())).append('\n')
            }
        }
    }

    // ---------------- Internetas ----------------

    private fun canUseWeb() = settings.webEnabled && web != null && web.online()

    /** Atsako į klausimą, ieškodamas internete, ir (jei leista) išmoksta atsakymą. */
    fun webAnswer(query: String): Reply? {
        val w = web ?: return null
        status("🔎 Ieško: $query")
        val pages = collectPages(w, query, settings.maxPages)
        if (pages.isEmpty()) return null
        val qv = Text.features(query, brain.dim)
        val cands = pages.flatMapIndexed { pi, p ->
            Text.sentences(p.text).take(60).mapIndexed { si, s ->
                val bonus = if (p.url.contains("wikipedia.org") && si < 3) 0.15f else 0f
                Triple(s, qv.dot(Text.features(s, brain.dim)) + bonus - pi * 0.01f, p.url)
            }
        }.filter { !blockedForLearning(it.first) }
        val sorted = cands.sortedByDescending { it.second }.distinctBy { Text.normalize(it.first) }
        val best = sorted.take(settings.answerSentences)
        more = sorted.drop(settings.answerSentences).filter { it.second > 0.05f }.take(12).map { it.first }
        moreSources = sorted.map { it.third }.distinct()
        if (best.isEmpty() || best.first().second < 0.08f) return null
        val answer = best.joinToString(" ") { it.first }
        val sources = best.map { it.third }.distinct()
        var id: Long? = null
        // Greitai pasenančios informacijos (orai, šiandien...) neįsimena
        val volatile = Text.words(query).any { it in setOf("siandien", "dabar", "rytoj", "vakar", "orai", "oras", "kursas", "naujienos", "sia", "sį", "sis") }
        val learn = settings.autoLearnWeb && !volatile
        if (learn) {
            val item = brain.teach(query, answer, "internetas")
            id = item.id; lastItem = item
        }
        return Reply(filterOut(answer), if (learn) "internetas 🌐 · išmokau" else "internetas 🌐", id, query, sources)
    }

    /** „Išmok: tema“ – pats ieško, skaito ir įsimena faktus. */
    fun learnTopic(topic: String): Reply {
        if (!canUseWeb()) return Reply("Mokytis iš interneto negaliu: nėra ryšio arba internetas išjungtas nustatymuose.", "mokymasis")
        val w = web!!
        status("📚 Mokausi: $topic")
        val pages = if (urlRe.matches(topic)) listOfNotNull(w.read(topic)) else collectPages(w, topic, settings.maxPages + 1)
        if (pages.isEmpty()) return Reply("Apie „$topic“ internete nieko neradau.${webFailReason()}", "mokymasis")

        val tv = Text.features(topic, brain.dim)
        val sentences = pages.flatMap { p ->
            val isWiki = p.url.contains("wikipedia.org")
            Text.sentences(p.text).take(80).mapIndexed { i, s ->
                val bonus = if (isWiki) (if (i == 0) 0.4f else 0.2f) else 0f
                Triple(s, tv.dot(Text.features(s, brain.dim)) + bonus, p.url)
            }
        }.filter { !blockedForLearning(it.first) && it.second > 0.05f }
            .distinctBy { Text.normalize(it.first) }
            .sortedByDescending { it.second }
            .take(settings.maxFactsPerTopic)

        if (sentences.isEmpty()) return Reply("Radau puslapių, bet nieko naudingo apie „$topic“.", "mokymasis")

        var added = 0
        for ((s, _, url) in sentences) {
            if (brain.similar(s, 0.9f).isNotEmpty()) continue
            brain.add(Kind.FACT, listOf(s), listOf(s), "internetas: " + host(url), train = false); added++
        }
        val order = pages.flatMap { Text.sentences(it.text) }.map { Text.normalize(it) }
        val summary = sentences.take(settings.answerSentences)
            .sortedBy { order.indexOf(Text.normalize(it.first)) }.joinToString(" ") { it.first }
        val t = topic.trim()
        val item = brain.add(Kind.REPLY, listOf(t, "kas yra $t", "papasakok apie $t", "ką žinai apie $t"),
            listOf(summary), "internetas", train = true)
        lastItem = item
        val srcs = sentences.map { it.third }.distinct()
        more = sentences.drop(settings.answerSentences).map { it.first }; moreSources = srcs
        return Reply(
            filterOut("📚 Išmokau $added naujų faktų apie „$t“ iš ${srcs.size} šaltinių.\n\nTrumpai: $summary\n\nDabar gali manęs klausti apie tai – atsakysiu ir be interneto."),
            "mokymasis 🧠🌐", item.id, t, srcs
        )
    }

    var lastWebError: String? = null; private set

    private fun collectPages(w: WebSource, query: String, max: Int): List<Page> {
        lastWebError = null
        val pages = ArrayList<Page>()
        runCatching { w.wiki(query) }.onFailure { lastWebError = "Wikipedia: ${it.message}" }.getOrNull()?.let { pages += it }
        val results = runCatching { w.search(query) }
            .onFailure { lastWebError = "Paieška: ${it.message}" }.getOrDefault(emptyList())
        for (r in results) {
            if (pages.size >= max) break
            if (pages.any { it.url == r.url }) continue
            status("🌐 Skaito: ${host(r.url)}")
            val page = runCatching { w.read(r.url) }.getOrNull()
            pages += page ?: r   // jei nepavyko atidaryti – bent paieškos aprašymas
        }
        return pages
    }

    /** Trumpas paaiškinimas, kai internete nieko negauta. */
    private fun webFailReason(): String =
        lastWebError?.let { " ($it)" } ?: ""

    private fun summarize(text: String, n: Int): String {
        val sents = Text.sentences(text).take(80)
        if (sents.isEmpty()) return ""
        val all = Text.features(text.take(6000), brain.dim)
        return sents.withIndex().sortedByDescending { all.dot(Text.features(it.value, brain.dim)) }
            .take(n).sortedBy { it.index }.joinToString(" ") { it.value }
    }

    private fun host(url: String) = url.substringAfter("://").substringBefore('/').removePrefix("www.")

    // ---------------- Atsiliepimai (👍 / 👎) ----------------

    fun feedback(itemId: Long, query: String, good: Boolean): Reply? {
        val item = brain.items.firstOrNull { it.id == itemId } ?: return null
        brain.reinforce(item, good)
        return if (good) {
            if (query.isNotBlank()) brain.addPattern(item, query)
            null
        } else {
            awaitingAnswerFor = query.ifBlank { null }
            lastQuery = query
            Reply("Supratau, atsakiau blogai. Kaip turėjau atsakyti į „$query“? (arba „praleisk“)", "mokymasis")
        }
    }

    // ---------------- Pažintis ir faktai ----------------

    private fun learnName(text: String): Reply {
        var t = text.trim().trimEnd('.', '!')
        for (pre in listOf("mano vardas yra", "mano vardas", "aš esu", "as esu", "vadinuosi", "esu", "aš", "as", "vardas")) {
            if (Text.normalize(t).startsWith(Text.normalize(pre) + " ")) { t = t.substring(pre.length).trim(); break }
        }
        val name = t.split(Regex("[\\s,]+")).firstOrNull { it.isNotBlank() }?.replaceFirstChar { it.uppercase() }
            ?: return Reply("Nesupratau. Kuo tu vardu?", "pažintis")
        settings = settings.copy(userName = name)
        learnFact("Mano vardas yra $name")
        onboarding = 2
        return Reply("Malonu susipažinti, $name! 🤝\n\nPapasakok šiek tiek apie save: kuo domiesi, ką mėgsti veikti?", "pažintis")
    }

    /** Ieško atsakymo tarp faktų, kuriuos papasakojai apie save. */
    private fun aboutMe(text: String, n: String): Reply? {
        val ws = n.split(' ')
        if (!Text.isQuestion(text) || ws.none { it in setOf("mano", "man", "as", "mane") }) return null
        val q = Text.contentStems(text)
        if (q.isEmpty()) return null
        val best = brain.items.filter { it.kind == Kind.FACT && it.source == "tu" }
            .map { it to q.count { s -> s in Text.contentStems(it.patterns.first()) }.toFloat() / q.size }
            .maxByOrNull { it.second } ?: return null
        if (best.second < 0.5f) return null
        lastItem = best.first
        return Reply(best.first.answers.first(), "atmintis · ${(best.second * 100).toInt()}%", best.first.id, text)
    }

    private fun learnFact(fact: String): Item {
        val clean = fact.trim().trimEnd('.')
        return brain.add(Kind.FACT, listOf(clean), listOf(Text.swapPerson(clean) + "."), "tu")
    }

    private val aboutMeStarts = listOf(
        "mano ", "as esu ", "as mokausi", "as gyvenu", "as megstu", "man patinka", "as turiu",
        "as domiuosi", "as lankau", "as zaidziu", "as moku", "as dirbu", "as noriu", "man nepatinka",
    )

    private fun isStatementAboutMe(n: String, text: String): Boolean =
        !Text.isQuestion(text) && n.split(' ').size >= 3 && aboutMeStarts.any { n.startsWith(it) } &&
            !n.startsWith("mano nuomone")

    // ---------------- Filtrai ----------------

    private fun hitsTopic(n: String): Boolean {
        val padded = " $n "
        return settings.list(settings.blockedTopics).any { padded.contains(" $it") }
    }

    private fun blockedForLearning(s: String): Boolean {
        if (!settings.learnFilter) return false
        val n = " " + Text.normalize(s) + " "
        return (settings.list(settings.blockedTopics) + settings.list(settings.blockedWords)).any { n.contains(" $it") }
    }

    private fun filterOut(s: String): String {
        if (!settings.filterOutput) return s
        var r = s
        for (w in settings.blockedWords.split(',', '\n', ';').map { it.trim() }.filter { it.isNotEmpty() }) {
            r = r.replace(Regex("(?i)\\b" + Regex.escape(w) + "\\w*"), "***")
        }
        return r
    }

    private fun out(r: Reply) = r.copy(text = filterOut(r.text))

    // ---------------- Šablonai ----------------

    private val days = listOf("pirmadienis", "antradienis", "trečiadienis", "ketvirtadienis", "penktadienis", "šeštadienis", "sekmadienis")

    private fun fill(s: String): String {
        val now = LocalDateTime.now()
        var r = s.replace("{vardas}", settings.userName.ifBlank { "drauge" })
            .replace("{botas}", settings.botName)
            .replace("{laikas}", now.format(DateTimeFormatter.ofPattern("HH:mm")))
            .replace("{data}", now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
            .replace("{diena}", days[now.dayOfWeek.value - 1])
        if ("{apie_mane}" in r) {
            val facts = brain.items.filter { it.kind == Kind.FACT && it.source == "tu" }.map { "• " + it.answers.first() }
            r = r.replace("{apie_mane}", if (facts.isEmpty()) "Dar nieko apie tave nežinau. Papasakok! Pvz.: „Mano mėgstamiausias dalykas yra informatika“."
            else "Štai ką apie tave žinau:\n" + facts.joinToString("\n"))
        }
        if ("{statistika}" in r) {
            val b = brain
            r = r.replace("{statistika}", "Žinau ${b.items.size} dalykų (${b.items.count { it.source == "tu" }} išmokei tu, " +
                "${b.items.count { it.source.startsWith("internetas") }} – iš interneto). Mano tinklas apmokytas ${b.trainedSteps} žingsnių.")
        }
        return r
    }

    private fun label(p: Prediction): String {
        val base = when {
            p.item.kind == Kind.FACT && p.item.source == "tu" -> "atmintis"
            p.item.source.startsWith("internetas") -> "išmokta iš interneto"
            p.item.source == "tekstas" -> "išmokta iš teksto"
            p.item.source == "tu" -> "išmokei tu"
            else -> "modelis"
        }
        return if (settings.debug) "$base · ${(p.confidence * 100).toInt()}% (tinklas ${(p.nnProb * 100).toInt()}%, panašumas ${(p.similarity * 100).toInt()}%)"
        else "$base · ${(p.confidence * 100).toInt()}%"
    }
}
