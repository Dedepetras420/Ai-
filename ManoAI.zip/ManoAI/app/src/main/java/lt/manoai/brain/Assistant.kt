package lt.manoai.brain

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/** Interneto šaltinis (Android dalyje – WebTools). */
interface WebSource {
    fun online(): Boolean
    fun wiki(query: String): Page?
    fun search(query: String): List<Page>
    fun read(url: String): Page?
}

data class Page(val title: String, val url: String, val text: String)

data class Reply(
    val text: String,
    val label: String,                 // iš kur atsakymas
    val itemId: Long? = null,          // kuriai žiniai galima duoti 👍/👎
    val query: String = "",
    val sources: List<String> = emptyList(),
)

/**
 * Tavo AI: sprendžia, kaip atsakyti, ir mokosi.
 * Tvarka: filtrai -> laukiami atsakymai -> komandos -> faktai apie tave ->
 *         skaičiuotuvas -> neuroninis tinklas -> internetas -> generatorius -> klausia tavęs.
 */
class Assistant(var brain: Brain, var settings: Settings, private val web: WebSource?) {
    private val rnd = Random.Default
    private var awaitingAnswerFor: String? = null
    private var onboarding = 0            // 1 – laukia vardo, 2 – laukia pomėgių
    private var lastQuery: String? = null
    private var lastItem: Item? = null
    var status: (String) -> Unit = {}

    init { applySettings() }

    fun applySettings() {
        brain.learningRate = settings.learningRate
        brain.nnWeight = settings.nnWeight
        brain.quickSteps = settings.quickSteps
        brain.markov.order = settings.markovOrder
    }

    /** Pirmas paleidimas: įkelia pradines žinias ir apmoko tinklą. */
    fun pretrain(onProgress: (Int, Float) -> Unit = { _, _ -> }) {
        for ((pats, ans) in StarterData.replies) brain.add(Kind.REPLY, pats, ans, "pradinis", train = false)
        brain.trainAll(settings.epochs, onProgress)
    }

    fun welcome(): Reply {
        return if (settings.userName.isBlank()) {
            onboarding = 1
            Reply("Labas! Aš esu ${settings.botName} – tavo asmeninis AI, parašytas nuo nulio. Mokausi iš mūsų pokalbių ir iš interneto.\n\nKuo tu vardu?", "sveikinimas")
        } else Reply(fill("Labas, {vardas}! Kuo galiu padėti?"), "sveikinimas")
    }

    // =============================================================

    fun reply(input: String): Reply {
        val text = input.trim()
        if (text.isEmpty()) return Reply("", "")
        val norm = Text.normalize(text)

        // 1. Filtrai
        if (settings.filterInput && hitsTopic(norm)) return out(Reply(settings.refusalText, "filtras"))

        // 2. Pažintis
        if (onboarding == 1) return out(learnName(text))
        if (onboarding == 2) {
            onboarding = 0
            learnFact("Aš domiuosi: $text")
            return out(Reply(fill("Įsiminiau! Dabar tave šiek tiek pažįstu, {vardas}. 😊\n\nKai ko nors nežinosiu – paklausiu tavęs arba paieškosiu internete. Parašyk „kaip tave mokyti“, kad sužinotum visas komandas."), "pažintis"))
        }

        // 3. Laukiam, kol išmokysi atsakymo
        awaitingAnswerFor?.let { q ->
            awaitingAnswerFor = null
            if (norm in setOf("praleisk", "nezinau", "nieko", "nesvarbu", "skip", "ne")) return out(Reply("Gerai, praleidžiam.", "mokymasis"))
            if (!Text.isQuestion(text) && !isCommand(norm)) {
                if (blockedForLearning(text)) return out(Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras"))
                val item = brain.teach(q, text, "tu")
                lastItem = item
                return out(Reply("Ačiū! Išmokau: į „$q“ atsakysiu „$text“.", "mokymasis 🧠"))
            }
        }

        // 4. Komandos
        command(text, norm)?.let { return out(it) }

        if (settings.autoLearnStyle) brain.markov.train(text)

        // 5. Faktai apie tave („Mano ... yra ...“)
        if (settings.autoLearnFacts && isStatementAboutMe(norm, text)) {
            if (blockedForLearning(text)) return out(Reply("To neįsiminsiu – tai yra tavo filtruose.", "filtras"))
            val fact = learnFact(text)
            return out(Reply("Įsiminiau: ${fact.answers.first()}", "atmintis 🧠"))
        }

        // 6. Skaičiuotuvas
        MathEval.tryAnswer(text)?.let { return out(Reply(it, "skaičiuotuvas")) }

        lastQuery = text

        // 7. Klausimas apie tave („koks mano vardas?“)
        aboutMe(text, norm)?.let { return out(it) }

        // 8. Neuroninis tinklas
        val pred = brain.predict(text)
        if (pred != null && pred.confidence >= settings.threshold) {
            lastItem = pred.item
            return out(Reply(fill(pred.item.answers.random(rnd)), label(pred), pred.item.id, text))
        }

        // 9. Internetas
        if (settings.webEnabled && settings.webWhenUnknown && web != null && web.online()) {
            webAnswer(text)?.let { return out(it) }
        }

        // 10. Generatorius
        if (settings.generator) {
            brain.markov.generate(text.split(" ").takeLast(2).joinToString(" "), 25, settings.genTemperature.toDouble())
                ?.let { return out(Reply(it, "generatorius")) }
        }

        // 11. Nežino – klausia tavęs
        lastItem = null
        if (settings.learnByAsking) {
            awaitingAnswerFor = text
            val hint = if (pred != null && settings.debug) "\n(geriausias spėjimas: „${pred.item.patterns.first()}“, ${(pred.confidence * 100).toInt()}%)" else ""
            return out(Reply("Dar nežinau, ką atsakyti. 🤔 Kaip turėčiau atsakyti? Parašyk atsakymą, ir aš išmoksiu (arba „praleisk“).$hint", "nežino"))
        }
        return out(Reply("Nežinau. Gali mane išmokyti: „Kai sakau X, atsakyk Y“.", "nežino"))
    }

    // ---------------- Komandos ----------------

    private val teachRe = Regex("""^kai\s+(sakau|rašau|rasau|klausiu|parašau|parasau)\s+(.+?),?\s+(atsakyk|sakyk|rašyk|rasyk)\s*:?\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val urlRe = Regex("""https?://\S+""")

    private fun after(text: String) = text.substringAfter(':', "").trim().ifEmpty { text.substringAfter(' ', "").trim() }

    private fun isCommand(n: String) = listOf("isimink", "ismok", "teisingai", "pamirsk", "ieskok", "web", "kurk").any { n.startsWith(it) }

    private fun command(text: String, n: String): Reply? {
        when {
            n.startsWith("isimink") -> {
                val f = after(text).ifEmpty { return Reply("Ką įsiminti? Pvz.: „Įsimink: mano mėgstamiausia spalva mėlyna“", "atmintis") }
                if (blockedForLearning(f)) return Reply("To neįsiminsiu – tai yra tavo filtruose.", "filtras")
                val item = learnFact(f)
                return Reply("Įsiminiau: ${item.answers.first()}", "atmintis 🧠")
            }
            n.startsWith("ismok") -> {
                val topic = text.substringAfter(':', text.drop(5)).trim()
                    .removePrefix("apie ").removePrefix("Apie ").trim()
                if (topic.isEmpty()) return Reply("Ką išmokti? Pvz.: „Išmok: juodosios skylės“", "mokymasis")
                return learnTopic(topic)
            }
            n.startsWith("teisingai") || n.startsWith("turejai atsakyti") -> {
                val ans = after(text)
                val q = lastQuery ?: return Reply("Nėra ką taisyti – pirma paklausk ko nors.", "mokymasis")
                if (ans.isEmpty()) return Reply("Parašyk: „Teisingai: tavo atsakymas“", "mokymasis")
                if (blockedForLearning(ans)) return Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras")
                lastItem?.let { brain.reinforce(it, false) }
                lastItem = brain.teach(q, ans, "tu")
                return Reply("Pataisiau! Į „$q“ dabar atsakysiu: „$ans“", "mokymasis 🧠")
            }
            n.startsWith("pamirsk") -> {
                val what = after(text)
                if (what.isEmpty()) return Reply("Ką pamiršti? Pvz.: „Pamiršk: mano mėgstamiausia spalva“", "atmintis")
                val hits = brain.similar(what, 0.6f).filter { it.first.source != "pradinis" }
                hits.forEach { brain.remove(it.first) }
                return Reply(if (hits.isEmpty()) "Nieko panašaus neradau." else "Pamiršau ${hits.size} dalykus.", "atmintis")
            }
            teachRe.matches(text) -> {
                val m = teachRe.find(text)!!
                val q = m.groupValues[2].trim('"', '„', '“', ' ')
                val a = m.groupValues[4].trim('"', '„', '“', ' ')
                if (blockedForLearning(q + " " + a)) return Reply("To neišmoksiu – tai yra tavo filtruose.", "filtras")
                lastItem = brain.teach(q, a, "tu")
                return Reply("Išmokau! Kai parašysi „$q“, atsakysiu „$a“.", "mokymasis 🧠")
            }
            n.startsWith("web ") || n.startsWith("ieskok") || text.startsWith("/web") -> {
                val q = text.removePrefix("/").substringAfter(' ').substringAfter(':').trim()
                if (!canUseWeb()) return Reply("Internetas neprieinamas arba išjungtas nustatymuose.", "internetas")
                return webAnswer(q) ?: Reply("Internete nieko tinkamo neradau.", "internetas")
            }
            n.startsWith("kurk") || text.startsWith("/kurk") -> {
                val seed = text.removePrefix("/").substringAfter(' ', "").substringAfter(':').trim()
                return Reply(brain.markov.generate(seed, 40, settings.genTemperature.toDouble())
                    ?: "Dar per mažai išmokau tavo stiliaus – pasikalbėkim daugiau.", "generatorius")
            }
            urlRe.containsMatchIn(text) && canUseWeb() -> {
                val url = urlRe.find(text)!!.value
                val page = web!!.read(url) ?: return Reply("Nepavyko atidaryti puslapio.", "internetas")
                val top = summarize(page.text, settings.answerSentences + 1)
                return Reply(filterOut(top.ifEmpty { page.title }), "internetas 🌐", sources = listOf(url))
            }
        }
        return null
    }

    // ---------------- Internetas ----------------

    private fun canUseWeb() = settings.webEnabled && web != null && web.online()

    /** Atsako į klausimą, ieškodamas internete, ir (jei leista) išmoksta atsakymą. */
    fun webAnswer(query: String): Reply? {
        val w = web ?: return null
        status("🔎 Ieško: $query")
        val pages = collectPages(w, query, settings.maxPages)
        if (pages.isEmpty()) return null
        val qv = Text.features(query, brain.dim)
        val cands = pages.flatMapIndexed { pi, p ->
            Text.sentences(p.text).take(60).mapIndexed { si, s ->
                val bonus = if (p.url.contains("wikipedia.org") && si < 3) 0.15f else 0f
                Triple(s, qv.dot(Text.features(s, brain.dim)) + bonus - pi * 0.01f, p.url)
            }
        }.filter { !blockedForLearning(it.first) }
        val best = cands.sortedByDescending { it.second }.take(settings.answerSentences)
        if (best.isEmpty() || best.first().second < 0.08f) return null
        val answer = best.joinToString(" ") { it.first }
        val sources = best.map { it.third }.distinct()
        var id: Long? = null
        // Greitai pasenančios informacijos (orai, šiandien...) neįsimena
        val volatile = Text.words(query).any { it in setOf("siandien", "dabar", "rytoj", "vakar", "orai", "oras", "kursas", "naujienos", "sia", "sį", "sis") }
        val learn = settings.autoLearnWeb && !volatile
        if (learn) {
            val item = brain.teach(query, answer, "internetas")
            id = item.id; lastItem = item
        }
        return Reply(filterOut(answer), if (learn) "internetas 🌐 · išmokau" else "internetas 🌐", id, query, sources)
    }

    /** „Išmok: tema“ – pats ieško, skaito ir įsimena faktus. */
    fun learnTopic(topic: String): Reply {
        if (!canUseWeb()) return Reply("Mokytis iš interneto negaliu: nėra ryšio arba internetas išjungtas nustatymuose.", "mokymasis")
        val w = web!!
        status("📚 Mokausi: $topic")
        val pages = if (urlRe.matches(topic)) listOfNotNull(w.read(topic)) else collectPages(w, topic, settings.maxPages + 1)
        if (pages.isEmpty()) return Reply("Apie „$topic“ internete nieko neradau.", "mokymasis")

        val tv = Text.features(topic, brain.dim)
        val sentences = pages.flatMap { p ->
            val isWiki = p.url.contains("wikipedia.org")
            Text.sentences(p.text).take(80).mapIndexed { i, s ->
                val bonus = if (isWiki) (if (i == 0) 0.4f else 0.2f) else 0f
                Triple(s, tv.dot(Text.features(s, brain.dim)) + bonus, p.url)
            }
        }.filter { !blockedForLearning(it.first) && it.second > 0.05f }
            .distinctBy { Text.normalize(it.first) }
            .sortedByDescending { it.second }
            .take(settings.maxFactsPerTopic)

        if (sentences.isEmpty()) return Reply("Radau puslapių, bet nieko naudingo apie „$topic“.", "mokymasis")

        var added = 0
        for ((s, _, url) in sentences) {
            if (brain.similar(s, 0.9f).isNotEmpty()) continue
            brain.add(Kind.FACT, listOf(s), listOf(s), "internetas: " + host(url), train = false); added++
        }
        val order = pages.flatMap { Text.sentences(it.text) }.map { Text.normalize(it) }
        val summary = sentences.take(settings.answerSentences)
            .sortedBy { order.indexOf(Text.normalize(it.first)) }.joinToString(" ") { it.first }
        val t = topic.trim()
        val item = brain.add(Kind.REPLY, listOf(t, "kas yra $t", "papasakok apie $t", "ką žinai apie $t"),
            listOf(summary), "internetas", train = true)
        lastItem = item
        val srcs = sentences.map { it.third }.distinct()
        return Reply(
            filterOut("📚 Išmokau $added naujų faktų apie „$t“ iš ${srcs.size} šaltinių.\n\nTrumpai: $summary\n\nDabar gali manęs klausti apie tai – atsakysiu ir be interneto."),
            "mokymasis 🧠🌐", item.id, t, srcs
        )
    }

    private fun collectPages(w: WebSource, query: String, max: Int): List<Page> {
        val pages = ArrayList<Page>()
        runCatching { w.wiki(query) }.getOrNull()?.let { pages += it }
        val results = runCatching { w.search(query) }.getOrDefault(emptyList())
        for (r in results) {
            if (pages.size >= max) break
            if (pages.any { it.url == r.url }) continue
            status("🌐 Skaito: ${host(r.url)}")
            val page = runCatching { w.read(r.url) }.getOrNull()
            pages += page ?: r   // jei nepavyko atidaryti – bent paieškos aprašymas
        }
        return pages
    }

    private fun summarize(text: String, n: Int): String {
        val sents = Text.sentences(text).take(80)
        if (sents.isEmpty()) return ""
        val all = Text.features(text.take(6000), brain.dim)
        return sents.withIndex().sortedByDescending { all.dot(Text.features(it.value, brain.dim)) }
            .take(n).sortedBy { it.index }.joinToString(" ") { it.value }
    }

    private fun host(url: String) = url.substringAfter("://").substringBefore('/').removePrefix("www.")

    // ---------------- Atsiliepimai (👍 / 👎) ----------------

    fun feedback(itemId: Long, query: String, good: Boolean): Reply? {
        val item = brain.items.firstOrNull { it.id == itemId } ?: return null
        brain.reinforce(item, good)
        return if (good) {
            if (query.isNotBlank()) brain.addPattern(item, query)
            null
        } else {
            awaitingAnswerFor = query.ifBlank { null }
            lastQuery = query
            Reply("Supratau, atsakiau blogai. Kaip turėjau atsakyti į „$query“? (arba „praleisk“)", "mokymasis")
        }
    }

    // ---------------- Pažintis ir faktai ----------------

    private fun learnName(text: String): Reply {
        var t = text.trim().trimEnd('.', '!')
        for (pre in listOf("mano vardas yra", "mano vardas", "aš esu", "as esu", "vadinuosi", "esu", "aš", "as", "vardas")) {
            if (Text.normalize(t).startsWith(Text.normalize(pre) + " ")) { t = t.substring(pre.length).trim(); break }
        }
        val name = t.split(Regex("[\\s,]+")).firstOrNull { it.isNotBlank() }?.replaceFirstChar { it.uppercase() }
            ?: return Reply("Nesupratau. Kuo tu vardu?", "pažintis")
        settings = settings.copy(userName = name)
        learnFact("Mano vardas yra $name")
        onboarding = 2
        return Reply("Malonu susipažinti, $name! 🤝\n\nPapasakok šiek tiek apie save: kuo domiesi, ką mėgsti veikti?", "pažintis")
    }

    /** Ieško atsakymo tarp faktų, kuriuos papasakojai apie save. */
    private fun aboutMe(text: String, n: String): Reply? {
        val ws = n.split(' ')
        if (!Text.isQuestion(text) || ws.none { it in setOf("mano", "man", "as", "mane") }) return null
        val q = Text.contentStems(text)
        if (q.isEmpty()) return null
        val best = brain.items.filter { it.kind == Kind.FACT && it.source == "tu" }
            .map { it to q.count { s -> s in Text.contentStems(it.patterns.first()) }.toFloat() / q.size }
            .maxByOrNull { it.second } ?: return null
        if (best.second < 0.5f) return null
        lastItem = best.first
        return Reply(best.first.answers.first(), "atmintis · ${(best.second * 100).toInt()}%", best.first.id, text)
    }

    private fun learnFact(fact: String): Item {
        val clean = fact.trim().trimEnd('.')
        return brain.add(Kind.FACT, listOf(clean), listOf(Text.swapPerson(clean) + "."), "tu")
    }

    private val aboutMeStarts = listOf(
        "mano ", "as esu ", "as mokausi", "as gyvenu", "as megstu", "man patinka", "as turiu",
        "as domiuosi", "as lankau", "as zaidziu", "as moku", "as dirbu", "as noriu", "man nepatinka",
    )

    private fun isStatementAboutMe(n: String, text: String): Boolean =
        !Text.isQuestion(text) && n.split(' ').size >= 3 && aboutMeStarts.any { n.startsWith(it) } &&
            !n.startsWith("mano nuomone")

    // ---------------- Filtrai ----------------

    private fun hitsTopic(n: String): Boolean {
        val padded = " $n "
        return settings.list(settings.blockedTopics).any { padded.contains(" $it") }
    }

    private fun blockedForLearning(s: String): Boolean {
        if (!settings.learnFilter) return false
        val n = " " + Text.normalize(s) + " "
        return (settings.list(settings.blockedTopics) + settings.list(settings.blockedWords)).any { n.contains(" $it") }
    }

    private fun filterOut(s: String): String {
        if (!settings.filterOutput) return s
        var r = s
        for (w in settings.blockedWords.split(',', '\n', ';').map { it.trim() }.filter { it.isNotEmpty() }) {
            r = r.replace(Regex("(?i)\\b" + Regex.escape(w) + "\\w*"), "***")
        }
        return r
    }

    private fun out(r: Reply) = r.copy(text = filterOut(r.text))

    // ---------------- Šablonai ----------------

    private val days = listOf("pirmadienis", "antradienis", "trečiadienis", "ketvirtadienis", "penktadienis", "šeštadienis", "sekmadienis")

    private fun fill(s: String): String {
        val now = LocalDateTime.now()
        var r = s.replace("{vardas}", settings.userName.ifBlank { "drauge" })
            .replace("{botas}", settings.botName)
            .replace("{laikas}", now.format(DateTimeFormatter.ofPattern("HH:mm")))
            .replace("{data}", now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
            .replace("{diena}", days[now.dayOfWeek.value - 1])
        if ("{apie_mane}" in r) {
            val facts = brain.items.filter { it.kind == Kind.FACT && it.source == "tu" }.map { "• " + it.answers.first() }
            r = r.replace("{apie_mane}", if (facts.isEmpty()) "Dar nieko apie tave nežinau. Papasakok! Pvz.: „Mano mėgstamiausias dalykas yra informatika“."
            else "Štai ką apie tave žinau:\n" + facts.joinToString("\n"))
        }
        if ("{statistika}" in r) {
            val b = brain
            r = r.replace("{statistika}", "Žinau ${b.items.size} dalykų (${b.items.count { it.source == "tu" }} išmokei tu, " +
                "${b.items.count { it.source.startsWith("internetas") }} – iš interneto). Mano tinklas apmokytas ${b.trainedSteps} žingsnių.")
        }
        return r
    }

    private fun label(p: Prediction): String {
        val base = when {
            p.item.kind == Kind.FACT && p.item.source == "tu" -> "atmintis"
            p.item.source.startsWith("internetas") -> "išmokta iš interneto"
            p.item.source == "tu" -> "išmokei tu"
            else -> "modelis"
        }
        return if (settings.debug) "$base · ${(p.confidence * 100).toInt()}% (tinklas ${(p.nnProb * 100).toInt()}%, panašumas ${(p.similarity * 100).toInt()}%)"
        else "$base · ${(p.confidence * 100).toInt()}%"
    }
}
