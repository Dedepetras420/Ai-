package lt.manoai.brain

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.tanh
import kotlin.random.Random

enum class Kind { REPLY, FACT }

/** Viena žinių vienetas: į ką (patterns) – kaip atsakyti (answers). */
class Item(
    val id: Long,
    var kind: Kind,
    val patterns: MutableList<String>,
    val answers: MutableList<String>,
    var source: String,        // "pradinis", "tu", "internetas", "atmintis"
    var score: Int = 0,        // 👍 / 👎 balansas
) {
    @Transient var vecs: List<Vec> = emptyList()
}

data class Prediction(val item: Item, val confidence: Float, val nnProb: Float, val similarity: Float)

/**
 * Tavo AI smegenys, parašytos nuo nulio:
 *  - neuroninis tinklas (įvestis -> paslėptas sluoksnis tanh -> softmax per žinias),
 *    apmokomas gradientiniu nusileidimu (backpropagation);
 *  - panašumo paieška (kosinusinis panašumas);
 *  - galutinis sprendimas sujungia abu.
 */
class Brain(val dim: Int = 4096, val hidden: Int = 48, seed: Int = 42) {
    private val rnd = Random(seed)

    // Tinklo svoriai
    private var w1 = FloatArray(dim * hidden) { (rnd.nextFloat() - 0.5f) * 0.1f }
    private var b1 = FloatArray(hidden)
    private val w2 = ArrayList<FloatArray>()   // po vieną stulpelį kiekvienai žiniai
    private val b2 = ArrayList<Float>()

    val items = ArrayList<Item>()
    val markov = Markov()

    // Statistika
    var trainedSteps = 0L; private set
    var lastLoss = 0f; private set

    // Nustatymai (keičiami kūrėjo meniu)
    var learningRate = 0.08f
    var nnWeight = 0.5f          // kiek pasitikėti tinklu vs panašumu
    var quickSteps = 12          // kiek mokymosi žingsnių išmokus naują dalyką

    private var nextId = 1L

    // ---------------- Tinklas ----------------

    private fun hiddenOf(x: Vec): FloatArray {
        val h = b1.copyOf()
        for (k in x.idx.indices) {
            val row = x.idx[k] * hidden; val xv = x.v[k]
            for (j in 0 until hidden) h[j] += w1[row + j] * xv
        }
        for (j in 0 until hidden) h[j] = tanh(h[j])
        return h
    }

    private fun softmax(h: FloatArray): FloatArray {
        val n = w2.size
        val z = FloatArray(n)
        var max = Float.NEGATIVE_INFINITY
        for (c in 0 until n) {
            val w = w2[c]; var s = b2[c]
            for (j in 0 until hidden) s += w[j] * h[j]
            z[c] = s; if (s > max) max = s
        }
        var sum = 0f
        for (c in 0 until n) { z[c] = exp(z[c] - max); sum += z[c] }
        for (c in 0 until n) z[c] /= sum
        return z
    }

    /** Vienas mokymosi žingsnis (backpropagation). Grąžina klaidą (loss). */
    private fun trainStep(x: Vec, target: Int): Float {
        val h = hiddenOf(x)
        val p = softmax(h)
        val lr = learningRate
        val dh = FloatArray(hidden)
        for (c in p.indices) {
            val g = p[c] - (if (c == target) 1f else 0f)
            if (g > -1e-5f && g < 1e-5f) continue
            val w = w2[c]
            for (j in 0 until hidden) { dh[j] += g * w[j]; w[j] -= lr * g * h[j] }
            b2[c] = b2[c] - lr * g
        }
        for (j in 0 until hidden) {
            val d = dh[j] * (1 - h[j] * h[j])
            if (d == 0f) continue
            b1[j] -= lr * d
            for (k in x.idx.indices) w1[x.idx[k] * hidden + j] -= lr * d * x.v[k]
        }
        trainedSteps++
        return -ln(p[target].coerceAtLeast(1e-7f))
    }

    private fun examples(): List<Pair<Vec, Int>> =
        items.flatMapIndexed { c, it -> it.vecs.map { v -> v to c } }

    /** Pilnas pertreniravimas per visas žinias. */
    fun trainAll(epochs: Int, onProgress: (epoch: Int, loss: Float) -> Unit = { _, _ -> }) {
        val ex = examples().toMutableList()
        if (ex.isEmpty()) return
        for (e in 1..epochs) {
            ex.shuffle(rnd)
            var total = 0f
            for ((v, c) in ex) total += trainStep(v, c)
            lastLoss = total / ex.size
            onProgress(e, lastLoss)
        }
    }

    /** Greitas mokymasis: naujas dalykas + keli seni (kad nepamirštų senų). */
    private fun trainQuick(col: Int) {
        val all = examples()
        val mine = all.filter { it.second == col }
        repeat(quickSteps) {
            var total = 0f; var n = 0
            for ((v, c) in mine) { total += trainStep(v, c); n++ }
            repeat(minOf(8, all.size)) { val (v, c) = all[rnd.nextInt(all.size)]; total += trainStep(v, c); n++ }
            lastLoss = total / n
        }
    }

    // ---------------- Žinios ----------------

    private fun vecsOf(item: Item) { item.vecs = item.patterns.map { Text.features(it, dim) } }

    fun add(kind: Kind, patterns: List<String>, answers: List<String>, source: String, train: Boolean = true): Item {
        // Jei jau yra labai panaši žinia – papildom ją
        val existing = if (kind == Kind.REPLY) items.firstOrNull { it.kind == Kind.REPLY &&
            it.patterns.any { p -> patterns.any { Text.normalize(it) == Text.normalize(p) } } } else null
        if (existing != null) {
            answers.filter { a -> existing.answers.none { it == a } }.let { existing.answers.addAll(0, it) }
            existing.source = source
            if (train) trainQuick(items.indexOf(existing))
            return existing
        }
        val item = Item(nextId++, kind, patterns.toMutableList(), answers.toMutableList(), source)
        vecsOf(item)
        items += item
        w2 += FloatArray(hidden) { (rnd.nextFloat() - 0.5f) * 0.1f }
        b2 += 0f
        if (train) trainQuick(items.lastIndex)
        return item
    }

    /**
     * Išmoksta „į X atsakyk Y“. Jei X jau priklauso kitai žiniai – perkelia
     * jį į naują žinią, kad nesugadintų kitų atsakymų.
     */
    fun teach(pattern: String, answer: String, source: String): Item {
        val norm = Text.normalize(pattern)
        items.firstOrNull { it.kind == Kind.REPLY && it.patterns.any { p -> Text.normalize(p) == norm } }?.let { ex ->
            if (ex.patterns.size == 1) {
                ex.answers.clear(); ex.answers += answer; ex.source = source; ex.score = 0
                trainQuick(items.indexOf(ex)); return ex
            }
            ex.patterns.removeAll { p -> Text.normalize(p) == norm }; vecsOf(ex)
        }
        return add(Kind.REPLY, listOf(pattern), listOf(answer), source)
    }

    fun addPattern(item: Item, pattern: String) {
        if (item.patterns.any { Text.normalize(it) == Text.normalize(pattern) }) return
        item.patterns += pattern; vecsOf(item)
        trainQuick(items.indexOf(item))
    }

    fun remove(item: Item) {
        val i = items.indexOf(item); if (i < 0) return
        items.removeAt(i); w2.removeAt(i); b2.removeAt(i)
    }

    fun reinforce(item: Item, good: Boolean) {
        item.score += if (good) 1 else -1
        if (good) trainQuick(items.indexOf(item))
    }

    // ---------------- Spėjimas ----------------

    fun predict(query: String, kinds: Set<Kind> = Kind.entries.toSet()): Prediction? {
        if (items.isEmpty()) return null
        val x = Text.features(query, dim)
        if (x.idx.isEmpty()) return null
        val p = softmax(hiddenOf(x))
        var best: Prediction? = null
        for ((c, item) in items.withIndex()) {
            if (item.kind !in kinds) continue
            val sim = item.vecs.maxOfOrNull { x.dot(it) } ?: 0f
            val bonus = (item.score * 0.02f).coerceIn(-0.15f, 0.1f)
            // Faktai remiasi panašumu (jų daug ir jie ilgi), atsakymai – tinklu + panašumu
            val conf = if (item.kind == Kind.FACT) sim + bonus else nnWeight * p[c] + (1 - nnWeight) * sim + bonus
            if (best == null || conf > best.confidence) best = Prediction(item, conf, p[c], sim)
        }
        return best
    }

    /** Visos žinios, panašios į tekstą (paieškai ir „pamiršk“ komandai). */
    fun similar(query: String, min: Float): List<Pair<Item, Float>> {
        val x = Text.features(query, dim)
        return items.map { it to (it.vecs.maxOfOrNull { v -> x.dot(v) } ?: 0f) }
            .filter { it.second >= min }.sortedByDescending { it.second }
    }

    // ---------------- Išsaugojimas ----------------

    fun save(): ByteArray {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { o ->
            o.writeInt(VERSION); o.writeInt(dim); o.writeInt(hidden)
            o.writeLong(nextId); o.writeLong(trainedSteps); o.writeFloat(lastLoss)
            for (f in w1) o.writeFloat(f)
            for (f in b1) o.writeFloat(f)
            o.writeInt(items.size)
            for ((i, it) in items.withIndex()) {
                o.writeLong(it.id); o.writeUTF(it.kind.name); o.writeUTF(it.source); o.writeInt(it.score)
                o.writeInt(it.patterns.size); it.patterns.forEach { s -> o.writeUTF(s.take(8000)) }
                o.writeInt(it.answers.size); it.answers.forEach { s -> o.writeUTF(s.take(8000)) }
                for (f in w2[i]) o.writeFloat(f)
                o.writeFloat(b2[i])
            }
            markov.write(o)
        }
        return bos.toByteArray()
    }

    companion object {
        private const val VERSION = 1

        fun load(bytes: ByteArray): Brain {
            DataInputStream(ByteArrayInputStream(bytes)).use { inp ->
                require(inp.readInt() == VERSION) { "Nepalaikoma modelio versija" }
                val b = Brain(inp.readInt(), inp.readInt())
                b.nextId = inp.readLong(); b.trainedSteps = inp.readLong(); b.lastLoss = inp.readFloat()
                for (i in b.w1.indices) b.w1[i] = inp.readFloat()
                for (i in b.b1.indices) b.b1[i] = inp.readFloat()
                repeat(inp.readInt()) {
                    val id = inp.readLong(); val kind = Kind.valueOf(inp.readUTF())
                    val src = inp.readUTF(); val score = inp.readInt()
                    val pats = MutableList(inp.readInt()) { inp.readUTF() }
                    val ans = MutableList(inp.readInt()) { inp.readUTF() }
                    val item = Item(id, kind, pats, ans, src, score)
                    b.vecsOf(item); b.items += item
                    b.w2 += FloatArray(b.hidden) { inp.readFloat() }
                    b.b2 += inp.readFloat()
                }
                b.markov.read(inp)
                return b
            }
        }
    }
}
