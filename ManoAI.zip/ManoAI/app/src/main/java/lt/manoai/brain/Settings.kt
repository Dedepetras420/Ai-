package lt.manoai.brain

import java.io.StringReader
import java.io.StringWriter
import java.util.Properties

enum class SearchProvider(val label: String) { DUCKDUCKGO("DuckDuckGo"), BRAVE("Brave"), SEARXNG("SearXNG") }

/** Visi nustatymai vienoje vietoje. Viskas keičiama programėlėje (⚙ ir 🛠). */
data class Settings(
    // Tu ir AI
    val userName: String = "",
    val botName: String = "Mano AI",

    // Apsaugos
    val pinHash: String = "",            // PIN kodas programėlei atidaryti (tuščia = be PIN)
    val devUnlocked: Boolean = false,
    val secureScreen: Boolean = true,
    val allowHttp: Boolean = false,

    // Mokymasis
    val autoLearnFacts: Boolean = true,  // „Mano ... yra ...“ -> įsimena automatiškai
    val learnByAsking: Boolean = true,   // kai nežino – klausia tavęs
    val autoLearnWeb: Boolean = true,    // ką rado internete – įsimena
    val autoLearnStyle: Boolean = true,  // mokosi tavo rašymo stiliaus (generatoriui)
    val learningRate: Float = 0.08f,
    val quickSteps: Int = 12,
    val epochs: Int = 30,                // pilnam pertreniravimui
    val hidden: Int = 48,                // neuronų skaičius (keičiant – modelis kuriamas iš naujo)
    val threshold: Float = 0.42f,        // kiek turi būti tikras, kad atsakytų
    val nnWeight: Float = 0.5f,          // neuroninio tinklo svoris vs panašumo paieška
    val generator: Boolean = false,      // kai nežino – bandyti sugeneruoti tekstą
    val markovOrder: Int = 2,
    val genTemperature: Float = 1.0f,
    val maxFactsPerTopic: Int = 25,      // „Išmok: ...“ – kiek faktų išsaugoti

    // Filtrai
    val filterInput: Boolean = true,
    val filterOutput: Boolean = true,
    val blockedWords: String = "",       // žodžiai, pakeičiami ***
    val blockedTopics: String = "",      // temos, apie kurias AI nekalba
    val refusalText: String = "Apie tai nekalbu (įjungtas filtras).",
    val learnFilter: Boolean = true,     // nemokyti to, kas yra filtruose

    // Internetas
    val webEnabled: Boolean = true,
    val webWhenUnknown: Boolean = true,  // nežino -> ieško internete
    val wikiLang: String = "lt",
    val searchProvider: SearchProvider = SearchProvider.DUCKDUCKGO,
    val searchKey: String = "",
    val searxUrl: String = "",
    val safeSearch: Int = 1,             // 0 išjungta, 1 vidutinė, 2 griežta
    val blockedDomains: String = "",
    val allowedDomains: String = "",
    val maxPages: Int = 3,
    val maxPageChars: Int = 8000,
    val answerSentences: Int = 3,

    val debug: Boolean = false,
) {
    fun list(s: String) = s.split(',', '\n', ';').map { Text.normalize(it) }.filter { it.isNotEmpty() }

    fun serialize(): String {
        val p = Properties()
        Settings::class.java.declaredFields.filter { !java.lang.reflect.Modifier.isStatic(it.modifiers) }.forEach { f ->
            f.isAccessible = true
            p.setProperty(f.name, f.get(this).toString())
        }
        return StringWriter().also { p.store(it, null) }.toString()
    }

    companion object {
        fun deserialize(text: String?): Settings {
            val d = Settings()
            if (text.isNullOrBlank()) return d
            val p = Properties().apply { load(StringReader(text)) }
            fun str(k: String, def: String) = p.getProperty(k) ?: def
            fun bool(k: String, def: Boolean) = p.getProperty(k)?.toBooleanStrictOrNull() ?: def
            fun int(k: String, def: Int) = p.getProperty(k)?.toIntOrNull() ?: def
            fun flt(k: String, def: Float) = p.getProperty(k)?.toFloatOrNull() ?: def
            return Settings(
                userName = str("userName", d.userName), botName = str("botName", d.botName),
                pinHash = str("pinHash", d.pinHash), devUnlocked = bool("devUnlocked", d.devUnlocked),
                secureScreen = bool("secureScreen", d.secureScreen), allowHttp = bool("allowHttp", d.allowHttp),
                autoLearnFacts = bool("autoLearnFacts", d.autoLearnFacts), learnByAsking = bool("learnByAsking", d.learnByAsking),
                autoLearnWeb = bool("autoLearnWeb", d.autoLearnWeb), autoLearnStyle = bool("autoLearnStyle", d.autoLearnStyle),
                learningRate = flt("learningRate", d.learningRate), quickSteps = int("quickSteps", d.quickSteps),
                epochs = int("epochs", d.epochs), hidden = int("hidden", d.hidden),
                threshold = flt("threshold", d.threshold), nnWeight = flt("nnWeight", d.nnWeight),
                generator = bool("generator", d.generator), markovOrder = int("markovOrder", d.markovOrder),
                genTemperature = flt("genTemperature", d.genTemperature), maxFactsPerTopic = int("maxFactsPerTopic", d.maxFactsPerTopic),
                filterInput = bool("filterInput", d.filterInput), filterOutput = bool("filterOutput", d.filterOutput),
                blockedWords = str("blockedWords", d.blockedWords), blockedTopics = str("blockedTopics", d.blockedTopics),
                refusalText = str("refusalText", d.refusalText), learnFilter = bool("learnFilter", d.learnFilter),
                webEnabled = bool("webEnabled", d.webEnabled), webWhenUnknown = bool("webWhenUnknown", d.webWhenUnknown),
                wikiLang = str("wikiLang", d.wikiLang),
                searchProvider = runCatching { SearchProvider.valueOf(str("searchProvider", "")) }.getOrDefault(d.searchProvider),
                searchKey = str("searchKey", d.searchKey), searxUrl = str("searxUrl", d.searxUrl),
                safeSearch = int("safeSearch", d.safeSearch), blockedDomains = str("blockedDomains", d.blockedDomains),
                allowedDomains = str("allowedDomains", d.allowedDomains), maxPages = int("maxPages", d.maxPages),
                maxPageChars = int("maxPageChars", d.maxPageChars), answerSentences = int("answerSentences", d.answerSentences),
                debug = bool("debug", d.debug),
            )
        }
    }
}
