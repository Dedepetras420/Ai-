package lt.manoai.brain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.sqrt
import kotlin.random.Random

/** Užduotys, kurias AI atlieka pats (be interneto). */
object Skills {
    private val days = listOf("pirmadienis", "antradienis", "trečiadienis", "ketvirtadienis", "penktadienis", "šeštadienis", "sekmadienis")
    private val months = listOf("sausio", "vasario", "kovo", "balandžio", "gegužės", "birželio", "liepos", "rugpjūčio", "rugsėjo", "spalio", "lapkričio", "gruodžio")

    private fun num(s: String) = s.replace(',', '.').toDouble()
    private fun fmt(d: Double): String =
        if (d == Math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString()
        else "%.4f".format(d).trimEnd('0').trimEnd('.', ',')

    fun dateText(d: LocalDate) = "${d.year} m. ${months[d.monthValue - 1]} ${d.dayOfMonth} d. (${days[d.dayOfWeek.value - 1]})"

    fun tryAnswer(text: String, today: LocalDate = LocalDate.now(), rnd: Random = Random.Default): String? {
        val low = text.lowercase()
        val n = Text.normalize(text)

        // Procentai: „15% nuo 200“, „20 procentų iš 50“
        Regex("""(\d+[.,]?\d*)\s*(%|proc\S*)\s*(nuo|iš|is)\s*(\d+[.,]?\d*)""").find(low)?.let {
            val p = num(it.groupValues[1]); val v = num(it.groupValues[4])
            return "${fmt(p)}% nuo ${fmt(v)} = ${fmt(v * p / 100)}"
        }
        // Šaknis: „šaknis iš 144“
        Regex("""saknis\s+(is\s+)?(\d+[.,]?\d*)""").find(n)?.let {
            val v = it.groupValues[2].toDouble()
            return "√${fmt(v)} = ${fmt(sqrt(v))}"
        }
        // Vienetų keitimas: „5 km į m“, „30 c į f“
        convert(low)?.let { return it }

        // Kauliukas, moneta, atsitiktinis skaičius
        if ("kauliuk" in n) return "🎲 Iškrito: ${rnd.nextInt(1, 7)}"
        if ("monet" in n && Regex("mesk|mest|metam|mesti|herbas").containsMatchIn(n))
            return "🪙 " + if (rnd.nextBoolean()) "Herbas!" else "Skaičius!"
        if (Regex("(sugalvok|atsitiktini|random)\\w*\\s+(skaici|skaicius)").containsMatchIn(n) || n.startsWith("sugalvok skaiciu")) {
            val r = Regex("""nuo\s+(-?\d+)\s+iki\s+(-?\d+)""").find(n)
            val a = r?.groupValues?.get(1)?.toInt() ?: 1; val b = r?.groupValues?.get(2)?.toInt() ?: 100
            return "Mano skaičius: ${rnd.nextInt(minOf(a, b), maxOf(a, b) + 1)}"
        }
        // Pasirinkimas: „išrink: pica ar makaronai“
        Regex("""^(išrink|isrink|pasirink|parink|rinkis)\s*:?\s*(.+)$""", RegexOption.IGNORE_CASE).find(text.trim())?.let {
            val opts = it.groupValues[2].split(Regex("""\s+ar\s+|,|\s+arba\s+""")).map { o -> o.trim(' ', '?', '.') }.filter { o -> o.isNotEmpty() }
            if (opts.size >= 2) return "Renkuosi: ${opts.random(rnd)} 👈"
        }
        // Kiek dienų iki ...
        if (n.startsWith("kiek dienu iki") || n.startsWith("kiek liko iki") || n.startsWith("po kiek dienu")) {
            val target = holiday(n, today) ?: explicitDate(low, today) ?: return null
            val d = ChronoUnit.DAYS.between(today, target.second)
            return if (d == 0L) "${target.first} – šiandien! 🎉" else "Iki ${target.first} liko $d d. (${dateText(target.second)})."
        }
        // Po N dienų / prieš N dienų
        Regex("""(po|pries)\s+(\d+)\s+(dien|savait|menes)""").find(n)?.let {
            if (!Regex("kokia|kelinta|kada|kuri|data|diena").containsMatchIn(n)) return@let
            val k = it.groupValues[2].toLong() * if (it.groupValues[1] == "po") 1 else -1
            val d = when (it.groupValues[3]) { "savait" -> today.plusWeeks(k); "menes" -> today.plusMonths(k); else -> today.plusDays(k) }
            return "Tai bus ${dateText(d)}."
        }
        // Kiek raidžių
        Regex("""kiek\s+(raidziu|simboliu)\s+(zodyje|zodis|zodzio|yra zodyje)?\s*(.+)""").find(n)?.let {
            val w = text.trim().split(Regex("\\s+")).last().trim('?', '.', '„', '“', '"', '!')
            return "Žodyje „$w“ yra ${w.count { c -> c.isLetter() }} raidžių."
        }
        // Kiek žodžių tekste
        if (n.startsWith("kiek zodziu")) {
            val t = text.substringAfter(':', "").trim()
            if (t.isNotEmpty()) return "Tekste yra ${t.split(Regex("\\s+")).count { it.isNotBlank() }} žodžių."
        }
        return null
    }

    private fun holiday(n: String, today: LocalDate): Pair<String, LocalDate>? {
        val list = listOf(
            "kaled" to Triple("Kalėdų", 12, 25), "kucio" to Triple("Kūčių", 12, 24),
            "nauju met" to Triple("Naujųjų metų", 1, 1), "vasario 16" to Triple("Vasario 16-osios", 2, 16),
            "kovo 11" to Triple("Kovo 11-osios", 3, 11), "jonin" to Triple("Joninių", 6, 24),
            "vasaros" to Triple("vasaros", 6, 1), "rugsejo 1" to Triple("Rugsėjo 1-osios", 9, 1),
            "helovin" to Triple("Helovino", 10, 31), "valentin" to Triple("Valentino dienos", 2, 14),
        )
        val (_, t) = list.firstOrNull { n.contains(it.first) } ?: return null
        var d = LocalDate.of(today.year, t.second, t.third)
        if (d.isBefore(today)) d = d.plusYears(1)
        return t.first to d
    }

    private fun explicitDate(low: String, today: LocalDate): Pair<String, LocalDate>? {
        Regex("""(\d{4})-(\d{1,2})-(\d{1,2})""").find(low)?.let {
            val d = LocalDate.of(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt())
            return it.value to d
        }
        val nn = Text.normalize(low)
        val monthsN = months.map { Text.normalize(it) }
        Regex("""(${monthsN.joinToString("|")})\s+(\d{1,2})""").find(nn)?.let {
            val m = monthsN.indexOf(it.groupValues[1]) + 1
            val ym = java.time.YearMonth.of(today.year, m)
            var d = ym.atDay(it.groupValues[2].toInt().coerceIn(1, ym.lengthOfMonth()))
            if (d.isBefore(today)) d = d.plusYears(1)
            return "${months[m - 1]} ${it.groupValues[2]} d." to d
        }
        return null
    }

    // ---------- Vienetai ----------

    private val length = mapOf("km" to 1000.0, "m" to 1.0, "dm" to 0.1, "cm" to 0.01, "mm" to 0.001, "mylios" to 1609.344, "mile" to 1609.344)
    private val mass = mapOf("t" to 1_000_000.0, "kg" to 1000.0, "g" to 1.0, "mg" to 0.001, "lb" to 453.592)
    private val volume = mapOf("l" to 1.0, "dl" to 0.1, "cl" to 0.01, "ml" to 0.001, "m3" to 1000.0)
    private val time = mapOf("d" to 86400.0, "h" to 3600.0, "val" to 3600.0, "min" to 60.0, "s" to 1.0, "sek" to 1.0)
    private val speed = mapOf("km/h" to 1 / 3.6, "m/s" to 1.0)

    private fun convert(low: String): String? {
        val m = Regex("""(-?\d+[.,]?\d*)\s*(°?[a-z/3]+)\s+(į|i|in|to)\s+(°?[a-z/3]+)""").find(low) ?: return null
        val v = num(m.groupValues[1])
        val from = m.groupValues[2].removePrefix("°"); val to = m.groupValues[4].removePrefix("°")
        if (from in setOf("c", "f") && to in setOf("c", "f") && from != to) {
            val r = if (from == "c") v * 9 / 5 + 32 else (v - 32) * 5 / 9
            return "${fmt(v)} °${from.uppercase()} = ${fmt(r)} °${to.uppercase()}"
        }
        for (table in listOf(length, mass, volume, time, speed)) {
            val a = table[from] ?: continue; val b = table[to] ?: continue
            return "${fmt(v)} $from = ${fmt(v * a / b)} $to"
        }
        return null
    }
}
