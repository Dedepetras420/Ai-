package lt.manoai.brain

import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.random.Random

/**
 * Teksto generatorius (Markovo grandinė). Mokosi iš visko, ką rašai,
 * ir bando rašyti panašiu stiliumi. Kuo daugiau rašai – tuo geriau.
 */
class Markov(var order: Int = 2) {
    private val table = HashMap<String, HashMap<String, Int>>()
    val size get() = table.size

    fun train(text: String) {
        val toks = listOf("<s>") + text.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() } + "</s>"
        if (toks.size < 3) return
        for (i in 1 until toks.size) {
            for (o in 1..order) {
                if (i - o < 0) break
                val key = toks.subList(i - o, i).joinToString(" ")
                val next = table.getOrPut(key) { HashMap() }
                next[toks[i]] = (next[toks[i]] ?: 0) + 1
            }
        }
        if (table.size > 200_000) table.keys.take(20_000).forEach { table.remove(it) }
    }

    fun generate(seed: String = "", maxWords: Int = 30, temperature: Double = 1.0, rnd: Random = Random): String? {
        if (table.isEmpty()) return null
        val out = ArrayList<String>()
        out += "<s>"
        out += seed.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        repeat(maxWords) {
            var next: String? = null
            for (o in order downTo 1) {
                if (out.size < o) continue
                val cand = table[out.takeLast(o).joinToString(" ")] ?: continue
                next = pick(cand, temperature, rnd); break
            }
            if (next == null || next == "</s>") return finish(out)
            out += next
        }
        return finish(out)
    }

    private fun finish(out: List<String>): String? {
        val words = out.drop(1)
        if (words.isEmpty()) return null
        return words.joinToString(" ").replaceFirstChar { it.uppercase() }
    }

    private fun pick(c: Map<String, Int>, t: Double, rnd: Random): String {
        val w = c.mapValues { Math.pow(it.value.toDouble(), 1.0 / t.coerceAtLeast(0.05)) }
        var r = rnd.nextDouble() * w.values.sum()
        for ((k, v) in w) { r -= v; if (r <= 0) return k }
        return w.keys.first()
    }

    fun clear() = table.clear()

    fun write(out: DataOutputStream) {
        out.writeInt(order); out.writeInt(table.size)
        for ((k, m) in table) {
            out.writeUTF(k); out.writeInt(m.size)
            for ((w, n) in m) { out.writeUTF(w); out.writeInt(n) }
        }
    }

    fun read(inp: DataInputStream) {
        table.clear(); order = inp.readInt()
        repeat(inp.readInt()) {
            val k = inp.readUTF(); val m = HashMap<String, Int>()
            repeat(inp.readInt()) { m[inp.readUTF()] = inp.readInt() }
            table[k] = m
        }
    }
}
