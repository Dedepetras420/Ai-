package lt.manoai

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import lt.manoai.brain.Kind
import lt.manoai.brain.SearchProvider
import lt.manoai.brain.Settings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent { HackerTheme { Surface(Modifier.fillMaxSize(), color = H.bg) { App() } } }
    }
}

// ======================= HAKERIŠKA TEMA =======================

object H {
    val bg = Color(0xFF0E1417)        // gilus, ramus fonas (Telegram tipo)
    val bar = Color(0xFF141C20)       // viršutinė/apatinė juosta
    val panel = Color(0xFF1A2429)     // gaunamos žinutės burbulas, kortelės
    val sent = Color(0xFF123528)      // siunčiamos žinutės burbulas (tamsi žalia)
    val green = Color(0xFF4ADE80)     // akcentas
    val greenDim = Color(0xFF2E8B57)
    val dim = Color(0xFF25313A)       // linijos/rėmeliai
    val text = Color(0xFFE7ECEA)      // pagrindinis tekstas
    val sentText = Color(0xFFDBF7E7)  // tekstas žaliame burbule
    val muted = Color(0xFF7E8C87)     // antraeilis
    val red = Color(0xFFE0576B)
    val mono = FontFamily.Monospace
}

@Composable
fun HackerTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = H.green, onPrimary = Color(0xFF04140B), secondary = H.green, onSecondary = Color.Black,
        background = H.bg, onBackground = H.text, surface = H.panel, onSurface = H.text,
        surfaceVariant = H.panel, onSurfaceVariant = H.muted, outline = H.dim, error = H.red,
        surfaceContainerHigh = H.panel, surfaceContainer = H.bar, surfaceContainerHighest = H.panel,
    )
    // Sans šriftas tekstui (skaitosi premium), mono paliekam tik akcentams
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(20.dp), extraLarge = RoundedCornerShape(24.dp),
        ),
        content = content
    )
}

/** Apvalus avataras su monograma – kaip Telegram pokalbio antraštėje. */
@Composable
fun Avatar(letter: String, size: androidx.compose.ui.unit.Dp = 38.dp) {
    Box(
        Modifier.size(size)
            .background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(H.green, H.greenDim)),
                androidx.compose.foundation.shape.CircleShape
            ),
        contentAlignment = Alignment.Center
    ) { Text(letter.take(1).uppercase(), color = Color(0xFF04140B), fontWeight = FontWeight.Bold, fontFamily = H.mono, fontSize = 18.sp) }
}

@Composable
fun BlinkingCursor() {
    val a by rememberInfiniteTransition(label = "c").animateFloat(
        1f, 0f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "c"
    )
    Text("▊", color = H.green, modifier = Modifier.alpha(if (a > 0.5f) 0.9f else 0.1f), fontFamily = H.mono, fontSize = 12.sp)
}

@Composable
fun App(vm: ChatViewModel = viewModel()) {
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(vm.settings.secureScreen) {
        if (vm.settings.secureScreen) activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    if (!vm.unlocked) PinScreen(vm) else ChatScreen(vm)
}

// ======================= PIN =======================

@Composable
fun PinScreen(vm: ChatViewModel) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(H.bg).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(vm.settings.botName, 72.dp)
        Spacer(Modifier.height(16.dp))
        Text(vm.settings.botName, color = H.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Užrakinta · įvesk PIN", color = H.muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        TextField(
            pin, { pin = it.filter(Char::isDigit); error = false }, singleLine = true,
            placeholder = { Text("• • • •", color = H.muted) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.width(220.dp).clip(RoundedCornerShape(22.dp)),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = H.panel, unfocusedContainerColor = H.panel,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                cursorColor = H.green, focusedTextColor = H.text, unfocusedTextColor = H.text,
            )
        )
        if (error) Text("Neteisingas PIN", color = H.red, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { if (!vm.unlock(pin)) { error = true; pin = "" } },
            shape = RoundedCornerShape(22.dp), modifier = Modifier.width(220.dp).height(46.dp),
            colors = ButtonDefaults.buttonColors(containerColor = H.green, contentColor = Color(0xFF04140B))
        ) { Text("Atrakinti", fontWeight = FontWeight.SemiBold) }
    }
}

// ======================= POKALBIS =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf("") }   // "settings", "knowledge", "dev", "train"
    val listState = rememberLazyListState()

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    val statusLine = when {
        vm.busy -> "renka atsakymą…"
        vm.settings.engine == lt.manoai.brain.Engine.ONLINE -> "tikras modelis" + if (vm.settings.secureScreen) " · 🔒" else ""
        else -> "savas modelis" + if (vm.settings.secureScreen) " · 🔒" else ""
    }
    Scaffold(
        modifier = Modifier.imePadding(),
        containerColor = H.bg,
        topBar = {
            Surface(color = H.bar, shadowElevation = 3.dp) {
                Column {
                    Row(
                        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(vm.settings.botName)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f).clickable { vm.onTitleTap() }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(vm.settings.botName, fontWeight = FontWeight.SemiBold, color = H.text, fontSize = 17.sp)
                                Spacer(Modifier.width(6.dp)); BlinkingCursor()
                            }
                            Text(statusLine, color = if (vm.busy) H.green else H.muted, fontSize = 12.sp)
                        }
                        IconTab("📚") { dialog = "train" }
                        IconTab("🧠") { dialog = "knowledge" }
                        IconTab("⚙") { dialog = "settings" }
                        if (vm.settings.devUnlocked) IconTab("🛠") { dialog = "dev" }
                    }
                    if (vm.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = H.green, trackColor = H.bar)
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(
                state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                itemsIndexed(vm.messages) { i, m -> Bubble(m, vm.settings.botName, vm.settings.userName, onRate = { good -> vm.rate(i, good) }) }
                item { Spacer(Modifier.height(8.dp)) }
            }
            Surface(color = H.bar) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        input, { input = it },
                        placeholder = { Text("Žinutė…", color = H.muted) },
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(22.dp)),
                        maxLines = 5,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = H.panel, unfocusedContainerColor = H.panel,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = H.green, focusedTextColor = H.text, unfocusedTextColor = H.text,
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    val active = !vm.busy && input.isNotBlank()
                    Box(
                        Modifier.size(46.dp)
                            .background(if (active) H.green else H.dim, androidx.compose.foundation.shape.CircleShape)
                            .clickable(enabled = active) { vm.send(input); input = "" },
                        contentAlignment = Alignment.Center
                    ) { Text("➤", color = if (active) Color(0xFF04140B) else H.muted, fontSize = 18.sp) }
                }
            }
        }
    }

    when (dialog) {
        "settings" -> SettingsDialog(vm) { dialog = "" }
        "knowledge" -> KnowledgeDialog(vm) { dialog = "" }
        "dev" -> DevDialog(vm) { dialog = "" }
        "train" -> TrainingDialog(vm) { dialog = "" }
    }
}

@Composable
fun IconTab(emoji: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center) { Text(emoji, fontSize = 18.sp) }
}

@Composable
fun Bubble(m: ChatMessage, botName: String, userName: String, onRate: (Boolean) -> Unit) {
    // Telegram tipo burbulas su „uodegėle“ prie savo pusės
    val shape = if (m.fromUser)
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 5.dp)
    else RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 5.dp, bottomEnd = 18.dp)
    Column(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start
    ) {
        Column(
            Modifier.widthIn(max = 320.dp)
                .background(if (m.fromUser) H.sent else H.panel, shape)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(m.text, color = if (m.fromUser) H.sentText else H.text, style = MaterialTheme.typography.bodyLarge, lineHeight = 20.sp)
            if (!m.fromUser) {
                m.sources.take(3).forEach {
                    Text("🔗 ${it.substringAfter("://").substringBefore("/")}", color = H.green.copy(alpha = 0.8f),
                        fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
        if (!m.fromUser && (m.label.isNotEmpty() || (m.itemId != null && !m.rated))) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, top = 1.dp)) {
                if (m.label.isNotEmpty()) Text(m.label, fontSize = 10.sp, color = H.muted, fontFamily = H.mono)
                if (m.itemId != null && !m.rated) {
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.clip(androidx.compose.foundation.shape.CircleShape).clickable { onRate(true) }.padding(3.dp)) { Text("👍", fontSize = 13.sp) }
                    Box(Modifier.clip(androidx.compose.foundation.shape.CircleShape).clickable { onRate(false) }.padding(3.dp)) { Text("👎", fontSize = 13.sp) }
                }
            }
        }
    }
}

// ======================= MOKYMO CENTRAS =======================

private const val TRAIN_EXAMPLE = """# Kiekviena eilutė – vienas pamokymas:
labas | sveikas | hey => Labas! | Sveikas, bosas!
kas tu | kas tu esi => Aš esu NULLMIND – tavo asmeninis AI.
Įsimink: Mano mėgstamiausia spalva yra žalia

Arba tiesiog įklijuok bet kokį tekstą (straipsnį, konspektą, knygos ištrauką) – AI įsimins sakinius kaip faktus ir galės pagal juos atsakyti."""

@Composable
fun TrainingDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importFile(it); onDismiss() }
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { vm.exportFile(it) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = H.panel,
        title = { Text("📚 Mokymo centras", color = H.green, fontWeight = FontWeight.Bold) },
        confirmButton = {
            TextButton(onClick = { vm.learnText(text); onDismiss() }, enabled = text.isNotBlank() && !vm.busy) { Text("Mokyti") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Uždaryti") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mokyk be ribų: klausimai ir atsakymai, faktai arba bet koks tekstas.",
                    style = MaterialTheme.typography.bodySmall, color = H.muted)
                OutlinedButton(onClick = { openFile.launch(arrayOf("text/*", "application/octet-stream")) }, Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)) { Text("📂 Įkelti .txt failą") }
                OutlinedTextField(
                    text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 320.dp),
                    placeholder = { Text("Įklijuok tekstą čia…", color = H.muted) }, shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = H.green, unfocusedBorderColor = H.dim, cursorColor = H.green)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { text = TRAIN_EXAMPLE }) { Text("Pavyzdys") }
                    TextButton(onClick = { text = "" }) { Text("Išvalyti") }
                }
                HorizontalDivider(color = H.dim)
                OutlinedButton(onClick = { saveFile.launch("nullmind_zinios.txt") }, Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)) { Text("💾 Eksportuoti visas žinias (.txt)") }
                Text("Eksportuotą failą gali pataisyti, papildyti (arba atsiųsti Claude, kad papildytų) ir vėl įkelti.",
                    style = MaterialTheme.typography.labelSmall, color = H.muted)
            }
        }
    )
}

// ======================= NUSTATYMAI =======================

@Composable
fun SettingsDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var d by remember { mutableStateOf(vm.settings) }
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nustatymai") },
        confirmButton = {
            TextButton(onClick = {
                vm.updateSettings(d)
                if (pin.isNotBlank()) vm.setPin(pin)
                onDismiss()
            }) { Text("Išsaugoti") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(d.userName, { d = d.copy(userName = it) }, label = { Text("Tavo vardas") }, singleLine = true)
                OutlinedTextField(d.botName, { d = d.copy(botName = it) }, label = { Text("AI vardas") }, singleLine = true)

                Section("Variklis")
                Chips("Kuris modelis atsakinėja", lt.manoai.brain.Engine.entries.map { it.label }, d.engine.label) { l ->
                    d = d.copy(engine = lt.manoai.brain.Engine.entries.first { it.label == l })
                }
                if (d.engine == lt.manoai.brain.Engine.ONLINE) {
                    Text("Tikras modelis supranta temas ir logiškai kalba. Nemokamą raktą gausi: aistudio.google.com → Get API key.",
                        style = MaterialTheme.typography.labelSmall, color = H.muted)
                    OutlinedTextField(d.apiKey, { d = d.copy(apiKey = it.trim()) }, label = { Text("API raktas") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(d.apiModel, { d = d.copy(apiModel = it.trim()) }, label = { Text("Modelio pavadinimas") }, singleLine = true)
                    Toggle("Perduoti modeliui, ką jį išmokei", d.useMemoryContext) { d = d.copy(useMemoryContext = it) }
                    if (d.devUnlocked) {
                        OutlinedTextField(d.apiEndpoint, { d = d.copy(apiEndpoint = it.trim()) }, label = { Text("API adresas") },
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(d.systemPrompt, { d = d.copy(systemPrompt = it) }, label = { Text("Sistemos nurodymas (tuščia = numatytas)") },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp))
                    }
                }

                Section("Bendra")
                Toggle("AI gali naudotis internetu", d.webEnabled) { d = d.copy(webEnabled = it) }
                Toggle("Kai nežino – klausia manęs (savas modelis)", d.learnByAsking) { d = d.copy(learnByAsking = it) }
                OutlinedTextField(
                    pin, { pin = it.filter(Char::isDigit) },
                    label = { Text(if (vm.settings.pinHash.isBlank()) "Nustatyti PIN kodą" else "Pakeisti PIN kodą") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                if (vm.settings.pinHash.isNotBlank()) {
                    OutlinedButton(onClick = { vm.setPin(""); onDismiss() }, Modifier.fillMaxWidth()) { Text("Išjungti PIN") }
                }
                OutlinedButton(onClick = { vm.clearChat(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Išvalyti pokalbį") }
                Text("Kūrėjo meniu: 7 kartus paspausk AI vardą viršuje.", style = MaterialTheme.typography.labelSmall, color = H.muted)
            }
        }
    )
}

// ======================= ŽINIOS =======================

@Composable
fun KnowledgeDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    val list = remember(filter, vm.knowledgeVersion) { vm.knowledge(filter) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Uždaryti") } },
        title = { Text("🧠 Ką AI žino") },
        text = {
            Column {
                Text(vm.stats(), style = MaterialTheme.typography.labelSmall, color = H.muted)
                OutlinedTextField(filter, { filter = it }, label = { Text("Ieškoti") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(list, key = { it.id }) { item ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text((if (item.kind == Kind.FACT) "📌 " else "💬 ") + item.patterns.first(),
                                    style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (item.kind == Kind.REPLY) Text("→ " + item.answers.first(),
                                    style = MaterialTheme.typography.bodySmall, color = H.muted, maxLines = 2)
                                Text("${item.source} · 👍${item.score}", style = MaterialTheme.typography.labelSmall, color = H.muted)
                            }
                            TextButton(onClick = { vm.forget(item) }) { Text("🗑") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    )
}

// ======================= KŪRĖJO MENIU =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var d by remember { mutableStateOf(vm.settings) }
    var raw by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf("") }  // "reset", "wipe"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🛠 Kūrėjo nustatymai") },
        confirmButton = { TextButton(onClick = { vm.updateSettings(d); onDismiss() }) { Text("Išsaugoti") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Section("Apsaugos")
                Toggle("Blokuoti ekrano nuotraukas", d.secureScreen) { d = d.copy(secureScreen = it) }
                Toggle("Leisti http:// (be šifravimo)", d.allowHttp) { d = d.copy(allowHttp = it) }

                Section("Mokymasis")
                Toggle("Įsiminti faktus apie mane („Mano … yra …“)", d.autoLearnFacts) { d = d.copy(autoLearnFacts = it) }
                Toggle("Kai nežino – klausti manęs", d.learnByAsking) { d = d.copy(learnByAsking = it) }
                Toggle("Kai nėra tikras – klausti „Ar turėjai omeny…?“", d.clarify) { d = d.copy(clarify = it) }
                Toggle("Įsiminti, ką rado internete", d.autoLearnWeb) { d = d.copy(autoLearnWeb = it) }
                Toggle("Mokytis mano rašymo stiliaus", d.autoLearnStyle) { d = d.copy(autoLearnStyle = it) }
                Toggle("Kai nežino – generuoti tekstą (eksperimentinis)", d.generator) { d = d.copy(generator = it) }
                Num("Mokymosi greitis (learning rate)", d.learningRate, 0.005f..0.3f) { d = d.copy(learningRate = it) }
                Num("Mokymosi žingsniai naujam dalykui", d.quickSteps.toFloat(), 1f..50f, int = true) { d = d.copy(quickSteps = it.toInt()) }
                Num("Epochos pertreniravimui", d.epochs.toFloat(), 5f..200f, int = true) { d = d.copy(epochs = it.toInt()) }
                Num("Užtikrintumo riba atsakyti", d.threshold, 0.1f..0.9f) { d = d.copy(threshold = it) }
                Num("Neuroninio tinklo svoris (vs panašumas)", d.nnWeight, 0f..1f) { d = d.copy(nnWeight = it) }
                Num("Generatoriaus kūrybiškumas", d.genTemperature, 0.2f..2f) { d = d.copy(genTemperature = it) }
                Num("Generatoriaus eilė (Markov)", d.markovOrder.toFloat(), 1f..3f, int = true) { d = d.copy(markovOrder = it.toInt()) }
                Num("„Išmok:“ – faktų iš vienos temos", d.maxFactsPerTopic.toFloat(), 5f..100f, int = true) { d = d.copy(maxFactsPerTopic = it.toInt()) }
                Num("Neuronų skaičius (taikoma kuriant iš naujo)", d.hidden.toFloat(), 64f..512f, int = true) { d = d.copy(hidden = it.toInt()) }
                OutlinedButton(onClick = { vm.updateSettings(d); vm.retrain(); onDismiss() }, Modifier.fillMaxWidth()) {
                    Text("🧠 Pertreniruoti tinklą")
                }
                OutlinedButton(onClick = { confirm = "reset" }, Modifier.fillMaxWidth()) { Text("Kurti modelį iš naujo (nuo nulio)") }

                Section("Filtrai ir saugumas")
                Toggle("Filtruoti mano žinutes (temos)", d.filterInput) { d = d.copy(filterInput = it) }
                Toggle("Filtruoti AI atsakymus (žodžiai → ***)", d.filterOutput) { d = d.copy(filterOutput = it) }
                Toggle("Nemokyti to, kas filtruose", d.learnFilter) { d = d.copy(learnFilter = it) }
                OutlinedTextField(d.blockedTopics, { d = d.copy(blockedTopics = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Draudžiamos temos") }, placeholder = { Text("politika, ...") })
                OutlinedTextField(d.blockedWords, { d = d.copy(blockedWords = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Draudžiami žodžiai") }, placeholder = { Text("keiksmažodžiai, ...") })
                OutlinedTextField(d.refusalText, { d = d.copy(refusalText = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Ką atsakyti, kai tema uždrausta") })

                Section("Internetas")
                Toggle("AI gali naudotis internetu", d.webEnabled) { d = d.copy(webEnabled = it) }
                Toggle("Kai nežino – ieškoti internete", d.webWhenUnknown) { d = d.copy(webWhenUnknown = it) }
                Chips("Wikipedia kalba", listOf("lt", "en"), d.wikiLang) { d = d.copy(wikiLang = it) }
                Chips("Paieška", SearchProvider.entries.map { it.label }, d.searchProvider.label) { l ->
                    d = d.copy(searchProvider = SearchProvider.entries.first { it.label == l })
                }
                if (d.searchProvider == SearchProvider.BRAVE) OutlinedTextField(d.searchKey, { d = d.copy(searchKey = it) },
                    label = { Text("Brave API raktas") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                if (d.searchProvider == SearchProvider.SEARXNG) OutlinedTextField(d.searxUrl, { d = d.copy(searxUrl = it) },
                    label = { Text("SearXNG adresas") }, placeholder = { Text("http://192.168.1.10:8080") }, singleLine = true)
                Chips("SafeSearch", listOf("Išjungta", "Vidutinė", "Griežta"), listOf("Išjungta", "Vidutinė", "Griežta")[d.safeSearch.coerceIn(0, 2)]) { l ->
                    d = d.copy(safeSearch = listOf("Išjungta", "Vidutinė", "Griežta").indexOf(l))
                }
                OutlinedTextField(d.blockedDomains, { d = d.copy(blockedDomains = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Blokuojamos svetainės") }, placeholder = { Text("tiktok.com, ...") })
                OutlinedTextField(d.allowedDomains, { d = d.copy(allowedDomains = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Leisti TIK šias (tuščia = visas)") }, placeholder = { Text("wikipedia.org, lrt.lt") })
                Num("Kiek puslapių skaityti", d.maxPages.toFloat(), 1f..6f, int = true) { d = d.copy(maxPages = it.toInt()) }
                Num("Teksto iš puslapio (simb.)", d.maxPageChars.toFloat(), 2000f..30000f, int = true) { d = d.copy(maxPageChars = it.toInt()) }
                Num("Sakinių atsakyme", d.answerSentences.toFloat(), 1f..6f, int = true) { d = d.copy(answerSentences = it.toInt()) }

                Section("Testavimas")
                Toggle("Debug: rodyti tikimybes ir klaidų detales", d.debug) { d = d.copy(debug = it) }
                OutlinedButton(onClick = { raw = vm.debugDump() }, Modifier.fillMaxWidth()) { Text("Modelio būsena ir nustatymai") }
                OutlinedButton(onClick = { confirm = "wipe" }, Modifier.fillMaxWidth()) { Text("Ištrinti VISKĄ") }
                OutlinedButton(onClick = { vm.lockDev(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Paslėpti kūrėjo meniu") }
            }
        }
    )

    raw?.let {
        AlertDialog(onDismissRequest = { raw = null },
            confirmButton = { TextButton(onClick = { raw = null }) { Text("Uždaryti") } },
            title = { Text("Modelio būsena") },
            text = { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.verticalScroll(rememberScrollState())) })
    }

    if (confirm.isNotEmpty()) AlertDialog(
        onDismissRequest = { confirm = "" },
        title = { Text(if (confirm == "reset") "Kurti modelį iš naujo?" else "Ištrinti viską?") },
        text = { Text(if (confirm == "reset") "AI pamirš viską, ką išmoko, ir pradės nuo pradinių žinių. Nustatymai liks."
            else "Bus ištrinti pokalbiai, visos žinios ir nustatymai. Atkurti nebus galima.") },
        confirmButton = {
            TextButton(onClick = {
                if (confirm == "reset") { vm.updateSettings(d); vm.resetBrain() } else vm.wipeAll()
                confirm = ""; onDismiss()
            }) { Text("Taip") }
        },
        dismissButton = { TextButton(onClick = { confirm = "" }) { Text("Ne") } }
    )
}

// ======================= Pagalbiniai =======================

@Composable
fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = 8.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
}

@Composable
fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Num(label: String, value: Float, range: ClosedFloatingPointRange<Float>, int: Boolean = false, onChange: (Float) -> Unit) {
    Text("$label: " + if (int) value.toInt().toString() else "%.3f".format(value), style = MaterialTheme.typography.bodySmall)
    Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chips(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) }) }
    }
}
