package lt.manoai.brain

/**
 * Pradinės žinios, kad AI suprastų tave nuo pirmos dienos.
 * Viską čia gali keisti, papildyti ar ištrinti – tai TAVO modelio mokymo duomenys.
 * {vardas} – tavo vardas, {botas} – AI vardas, {laikas}, {data}, {diena} – dabartinis laikas.
 */
object StarterData {
    val replies: List<Pair<List<String>, List<String>>> = listOf(
        listOf("labas", "sveikas", "sveiki", "labukas", "hey", "hi", "hello", "labas rytas", "laba diena", "labas vakaras", "sveikutis", "čia") to
            listOf("Labas, {vardas}! Kuo galiu padėti?", "Sveikas, {vardas}! Ką veiksim?", "Labas! Smagu tave matyti, {vardas}."),
        listOf("iki", "viso gero", "ate", "bye", "iki pasimatymo", "einu miegoti", "labanakt", "iki rytojaus") to
            listOf("Iki, {vardas}! 👋", "Viso gero! Grįžk greitai.", "Labanakt! Iki kito karto."),
        listOf("ačiū", "aciu", "dėkui", "dekui", "ačiū labai", "thanks", "super ačiū") to
            listOf("Nėra už ką!", "Visada prašom, {vardas}!", "Smagu, kad padėjau."),
        listOf("kaip sekasi", "kaip laikaisi", "kaip tu", "kaip gyveni", "kas naujo", "kaip reikalai") to
            listOf("Man puikiai – kiekvieną dieną išmokstu kažką naujo! O tau kaip sekasi?", "Gerai, ačiū! O kaip tau, {vardas}?"),
        listOf("man gerai", "gerai", "puikiai", "neblogai", "viskas gerai", "normaliai", "super") to
            listOf("Smagu girdėti! 😊", "Puiku! Ką šiandien veiksim?"),
        listOf("man blogai", "liūdna", "prastai", "nuobodu", "pavargau", "blogai sekasi") to
            listOf("Gaila girdėti. Nori papasakoti, kas nutiko?", "Būna tokių dienų. Gal galiu kuo nors padėti?"),
        listOf("kas tu", "kas tu esi", "kas tu toks", "ar tu robotas", "ar tu dirbtinis intelektas", "kas tave sukūrė") to
            listOf("Aš esu {botas} – tavo asmeninis AI, parašytas nuo nulio. Mano smegenys yra neuroninis tinklas, kuris mokosi iš mūsų pokalbių."),
        listOf("koks tavo vardas", "kuo tu vardu", "kaip tave vadinti", "tavo vardas") to
            listOf("Mano vardas {botas}. Jį gali pakeisti nustatymuose."),
        listOf("ką moki", "ką gali", "ką tu moki daryti", "kuo gali padėti", "pagalba", "help", "ką tu sugebi") to
            listOf("Moku: kalbėtis ir mokytis iš tavęs, ieškoti internete (Wikipedia ir paieška), skaičiuoti (pvz., 12*7), pasakyti laiką ir datą, prisiminti, ką man papasakoji. Parašyk „kaip tave mokyti“, kad sužinotum daugiau."),
        listOf("kaip tave mokyti", "kaip tave išmokyti", "kaip mokyti", "kaip tu mokaisi", "mokymas") to
            listOf("Mane mokyti paprasta:\n• „Įsimink: …“ – įsiminsiu faktą\n• „Kai sakau X, atsakyk Y“ – išmoksiu atsakymą\n• 👍 / 👎 po mano atsakymu – suprasiu, ar gerai atsakiau\n• „Teisingai: …“ – pataisysi mano paskutinį atsakymą\n• Kai nežinau, paklausiu tavęs, kaip atsakyti\n• „Pamiršk: …“ – ištrinsiu\n• „/web …“ – ieškosiu internete"),
        listOf("kiek valandų", "kiek laiko", "kelinta valanda", "koks laikas", "kiek dabar valandų") to
            listOf("Dabar {laikas}."),
        listOf("kokia šiandien data", "kelinta šiandien", "kokia data", "kokia šiandien diena", "kokia diena") to
            listOf("Šiandien {diena}, {data}."),
        listOf("papasakok anekdotą", "pajuokauk", "anekdotas", "prajuokink mane", "juokelis") to
            listOf(
                "Kodėl programuotojai nemėgsta gamtos? Ten per daug klaidų (bugs). 🐛",
                "Mokytoja: „Kodėl vėluoji?“ Mokinys: „Nes pamoka prasidėjo prieš man ateinant.“",
                "Kiek programuotojų reikia lemputei pakeisti? Nė vieno – tai aparatinės įrangos problema.",
            ),
        listOf("tu protingas", "tu šaunus", "gerai atsakei", "tu geras", "šaunuolis", "tu nuostabus") to
            listOf("Ačiū! Esu toks protingas, kiek tu mane išmokai. 😄", "Ačiū, {vardas}! Stengiuosi."),
        listOf("tu kvailas", "tu nieko nesupranti", "blogai", "neteisingai", "nesąmonė") to
            listOf("Atsiprašau! Paspausk 👎 ir parašyk, kaip turėjau atsakyti – išmoksiu.", "Dar mokausi. Parašyk „Teisingai: …“ ir pataisysiu save."),
        listOf("taip", "jo", "aha", "tikrai", "yes") to listOf("Gerai! 👍", "Supratau."),
        listOf("ne", "nea", "nenoriu", "no") to listOf("Gerai, supratau.", "Jokių problemų."),
        listOf("ką veiki", "ką darai", "ką veikiat", "kuo užsiimi") to
            listOf("Kalbuosi su tavimi ir mokausi! O tu ką veiki?"),
        listOf("ką žinai apie mane", "ką apie mane žinai", "kas aš esu", "ar mane pažįsti") to
            listOf("{apie_mane}"),
        listOf("kiek tu žinai", "kiek esi išmokęs", "tavo statistika", "kiek žinių turi") to
            listOf("{statistika}"),
    )
}
