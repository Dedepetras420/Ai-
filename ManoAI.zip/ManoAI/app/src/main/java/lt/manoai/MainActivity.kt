package lt.manoai

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import lt.manoai.brain.Kind
import lt.manoai.brain.SearchProvider
import lt.manoai.brain.Settings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: ChatViewModel = viewModel()) {
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(vm.settings.secureScreen) {
        if (vm.settings.secureScreen) activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    if (!vm.unlocked) PinScreen(vm) else ChatScreen(vm)
}

// ======================= PIN =======================

@Composable
fun PinScreen(vm: ChatViewModel) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", style = MaterialTheme.typography.displayMedium)
        Text("Įvesk PIN kodą", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            pin, { pin = it; error = false }, singleLine = true, isError = error,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
        if (error) Text("Neteisingas PIN", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (!vm.unlock(pin)) { error = true; pin = "" } }) { Text("Atrakinti") }
    }
}

// ======================= POKALBIS =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf("") }   // "settings", "knowledge", "dev"
    val listState = rememberLazyListState()

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        vm.settings.botName + if (vm.settings.secureScreen) " 🔒" else "",
                        modifier = Modifier.clickable { vm.onTitleTap() }
                    )
                },
                actions = {
                    TextButton(onClick = { dialog = "knowledge" }) { Text("🧠") }
                    TextButton(onClick = { dialog = "settings" }) { Text("⚙") }
                    if (vm.settings.devUnlocked) TextButton(onClick = { dialog = "dev" }) { Text("🛠") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(vm.status, style = MaterialTheme.typography.labelSmall, color = Color.Gray,
                modifier = Modifier.padding(horizontal = 12.dp))
            if (vm.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp)) {
                itemsIndexed(vm.messages) { i, m -> Bubble(m, onRate = { good -> vm.rate(i, good) }) }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    input, { input = it }, placeholder = { Text("Rašyk arba „Išmok: …“") },
                    modifier = Modifier.weight(1f), maxLines = 5
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { vm.send(input); input = "" }, enabled = !vm.busy && input.isNotBlank()) {
                    Text(if (vm.busy) "…" else "➤")
                }
            }
        }
    }

    when (dialog) {
        "settings" -> SettingsDialog(vm) { dialog = "" }
        "knowledge" -> KnowledgeDialog(vm) { dialog = "" }
        "dev" -> DevDialog(vm) { dialog = "" }
    }
}

@Composable
fun Bubble(m: ChatMessage, onRate: (Boolean) -> Unit) {
    val bg = if (m.fromUser) Color(0xFF2E5BFF) else Color(0xFF2A2A2E)
    Column(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start
    ) {
        Text(m.text, color = Color.White,
            modifier = Modifier.widthIn(max = 320.dp).background(bg, RoundedCornerShape(14.dp)).padding(10.dp))
        if (!m.fromUser) {
            m.sources.take(4).forEach {
                Text("🔗 $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8AB4F8), maxLines = 1)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (m.label.isNotEmpty()) Text(m.label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                if (m.itemId != null && !m.rated) {
                    TextButton(onClick = { onRate(true) }, contentPadding = PaddingValues(4.dp)) { Text("👍") }
                    TextButton(onClick = { onRate(false) }, contentPadding = PaddingValues(4.dp)) { Text("👎") }
                }
            }
        }
    }
}

// ======================= NUSTATYMAI =======================

@Composable
fun SettingsDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var d by remember { mutableStateOf(vm.settings) }
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nustatymai") },
        confirmButton = {
            TextButton(onClick = {
                vm.updateSettings(d)
                if (pin.isNotBlank()) vm.setPin(pin)
                onDismiss()
            }) { Text("Išsaugoti") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(d.userName, { d = d.copy(userName = it) }, label = { Text("Tavo vardas") }, singleLine = true)
                OutlinedTextField(d.botName, { d = d.copy(botName = it) }, label = { Text("AI vardas") }, singleLine = true)
                Toggle("AI gali naudotis internetu", d.webEnabled) { d = d.copy(webEnabled = it) }
                Toggle("Kai nežino – klausia manęs", d.learnByAsking) { d = d.copy(learnByAsking = it) }
                OutlinedTextField(
                    pin, { pin = it.filter(Char::isDigit) },
                    label = { Text(if (vm.settings.pinHash.isBlank()) "Nustatyti PIN kodą" else "Pakeisti PIN kodą") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                if (vm.settings.pinHash.isNotBlank()) {
                    OutlinedButton(onClick = { vm.setPin(""); onDismiss() }, Modifier.fillMaxWidth()) { Text("Išjungti PIN") }
                }
                OutlinedButton(onClick = { vm.clearChat(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Išvalyti pokalbį") }
                Text("Kūrėjo meniu: 7 kartus paspausk AI vardą viršuje.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
        }
    )
}

// ======================= ŽINIOS =======================

@Composable
fun KnowledgeDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    val list = remember(filter, vm.knowledgeVersion) { vm.knowledge(filter) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Uždaryti") } },
        title = { Text("🧠 Ką AI žino") },
        text = {
            Column {
                Text(vm.stats(), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                OutlinedTextField(filter, { filter = it }, label = { Text("Ieškoti") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(list, key = { it.id }) { item ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text((if (item.kind == Kind.FACT) "📌 " else "💬 ") + item.patterns.first(),
                                    style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (item.kind == Kind.REPLY) Text("→ " + item.answers.first(),
                                    style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 2)
                                Text("${item.source} · 👍${item.score}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                            TextButton(onClick = { vm.forget(item) }) { Text("🗑") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    )
}

// ======================= KŪRĖJO MENIU =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var d by remember { mutableStateOf(vm.settings) }
    var raw by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf("") }  // "reset", "wipe"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🛠 Kūrėjo nustatymai") },
        confirmButton = { TextButton(onClick = { vm.updateSettings(d); onDismiss() }) { Text("Išsaugoti") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Section("Apsaugos")
                Toggle("Blokuoti ekrano nuotraukas", d.secureScreen) { d = d.copy(secureScreen = it) }
                Toggle("Leisti http:// (be šifravimo)", d.allowHttp) { d = d.copy(allowHttp = it) }

                Section("Mokymasis")
                Toggle("Įsiminti faktus apie mane („Mano … yra …“)", d.autoLearnFacts) { d = d.copy(autoLearnFacts = it) }
                Toggle("Kai nežino – klausti manęs", d.learnByAsking) { d = d.copy(learnByAsking = it) }
                Toggle("Įsiminti, ką rado internete", d.autoLearnWeb) { d = d.copy(autoLearnWeb = it) }
                Toggle("Mokytis mano rašymo stiliaus", d.autoLearnStyle) { d = d.copy(autoLearnStyle = it) }
                Toggle("Kai nežino – generuoti tekstą (eksperimentinis)", d.generator) { d = d.copy(generator = it) }
                Num("Mokymosi greitis (learning rate)", d.learningRate, 0.005f..0.3f) { d = d.copy(learningRate = it) }
                Num("Mokymosi žingsniai naujam dalykui", d.quickSteps.toFloat(), 1f..50f, int = true) { d = d.copy(quickSteps = it.toInt()) }
                Num("Epochos pertreniravimui", d.epochs.toFloat(), 5f..200f, int = true) { d = d.copy(epochs = it.toInt()) }
                Num("Užtikrintumo riba atsakyti", d.threshold, 0.1f..0.9f) { d = d.copy(threshold = it) }
                Num("Neuroninio tinklo svoris (vs panašumas)", d.nnWeight, 0f..1f) { d = d.copy(nnWeight = it) }
                Num("Generatoriaus kūrybiškumas", d.genTemperature, 0.2f..2f) { d = d.copy(genTemperature = it) }
                Num("Generatoriaus eilė (Markov)", d.markovOrder.toFloat(), 1f..3f, int = true) { d = d.copy(markovOrder = it.toInt()) }
                Num("„Išmok:“ – faktų iš vienos temos", d.maxFactsPerTopic.toFloat(), 5f..100f, int = true) { d = d.copy(maxFactsPerTopic = it.toInt()) }
                Num("Neuronų skaičius (taikoma kuriant iš naujo)", d.hidden.toFloat(), 16f..128f, int = true) { d = d.copy(hidden = it.toInt()) }
                OutlinedButton(onClick = { vm.updateSettings(d); vm.retrain(); onDismiss() }, Modifier.fillMaxWidth()) {
                    Text("🧠 Pertreniruoti tinklą")
                }
                OutlinedButton(onClick = { confirm = "reset" }, Modifier.fillMaxWidth()) { Text("Kurti modelį iš naujo (nuo nulio)") }

                Section("Filtrai ir saugumas")
                Toggle("Filtruoti mano žinutes (temos)", d.filterInput) { d = d.copy(filterInput = it) }
                Toggle("Filtruoti AI atsakymus (žodžiai → ***)", d.filterOutput) { d = d.copy(filterOutput = it) }
                Toggle("Nemokyti to, kas filtruose", d.learnFilter) { d = d.copy(learnFilter = it) }
                OutlinedTextField(d.blockedTopics, { d = d.copy(blockedTopics = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Draudžiamos temos") }, placeholder = { Text("politika, ...") })
                OutlinedTextField(d.blockedWords, { d = d.copy(blockedWords = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Draudžiami žodžiai") }, placeholder = { Text("keiksmažodžiai, ...") })
                OutlinedTextField(d.refusalText, { d = d.copy(refusalText = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Ką atsakyti, kai tema uždrausta") })

                Section("Internetas")
                Toggle("AI gali naudotis internetu", d.webEnabled) { d = d.copy(webEnabled = it) }
                Toggle("Kai nežino – ieškoti internete", d.webWhenUnknown) { d = d.copy(webWhenUnknown = it) }
                Chips("Wikipedia kalba", listOf("lt", "en"), d.wikiLang) { d = d.copy(wikiLang = it) }
                Chips("Paieška", SearchProvider.entries.map { it.label }, d.searchProvider.label) { l ->
                    d = d.copy(searchProvider = SearchProvider.entries.first { it.label == l })
                }
                if (d.searchProvider == SearchProvider.BRAVE) OutlinedTextField(d.searchKey, { d = d.copy(searchKey = it) },
                    label = { Text("Brave API raktas") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                if (d.searchProvider == SearchProvider.SEARXNG) OutlinedTextField(d.searxUrl, { d = d.copy(searxUrl = it) },
                    label = { Text("SearXNG adresas") }, placeholder = { Text("http://192.168.1.10:8080") }, singleLine = true)
                Chips("SafeSearch", listOf("Išjungta", "Vidutinė", "Griežta"), listOf("Išjungta", "Vidutinė", "Griežta")[d.safeSearch.coerceIn(0, 2)]) { l ->
                    d = d.copy(safeSearch = listOf("Išjungta", "Vidutinė", "Griežta").indexOf(l))
                }
                OutlinedTextField(d.blockedDomains, { d = d.copy(blockedDomains = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Blokuojamos svetainės") }, placeholder = { Text("tiktok.com, ...") })
                OutlinedTextField(d.allowedDomains, { d = d.copy(allowedDomains = it) }, Modifier.fillMaxWidth(),
                    label = { Text("Leisti TIK šias (tuščia = visas)") }, placeholder = { Text("wikipedia.org, lrt.lt") })
                Num("Kiek puslapių skaityti", d.maxPages.toFloat(), 1f..6f, int = true) { d = d.copy(maxPages = it.toInt()) }
                Num("Teksto iš puslapio (simb.)", d.maxPageChars.toFloat(), 2000f..30000f, int = true) { d = d.copy(maxPageChars = it.toInt()) }
                Num("Sakinių atsakyme", d.answerSentences.toFloat(), 1f..6f, int = true) { d = d.copy(answerSentences = it.toInt()) }

                Section("Testavimas")
                Toggle("Debug: rodyti tikimybes ir klaidų detales", d.debug) { d = d.copy(debug = it) }
                OutlinedButton(onClick = { raw = vm.debugDump() }, Modifier.fillMaxWidth()) { Text("Modelio būsena ir nustatymai") }
                OutlinedButton(onClick = { confirm = "wipe" }, Modifier.fillMaxWidth()) { Text("Ištrinti VISKĄ") }
                OutlinedButton(onClick = { vm.lockDev(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Paslėpti kūrėjo meniu") }
            }
        }
    )

    raw?.let {
        AlertDialog(onDismissRequest = { raw = null },
            confirmButton = { TextButton(onClick = { raw = null }) { Text("Uždaryti") } },
            title = { Text("Modelio būsena") },
            text = { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.verticalScroll(rememberScrollState())) })
    }

    if (confirm.isNotEmpty()) AlertDialog(
        onDismissRequest = { confirm = "" },
        title = { Text(if (confirm == "reset") "Kurti modelį iš naujo?" else "Ištrinti viską?") },
        text = { Text(if (confirm == "reset") "AI pamirš viską, ką išmoko, ir pradės nuo pradinių žinių. Nustatymai liks."
            else "Bus ištrinti pokalbiai, visos žinios ir nustatymai. Atkurti nebus galima.") },
        confirmButton = {
            TextButton(onClick = {
                if (confirm == "reset") { vm.updateSettings(d); vm.resetBrain() } else vm.wipeAll()
                confirm = ""; onDismiss()
            }) { Text("Taip") }
        },
        dismissButton = { TextButton(onClick = { confirm = "" }) { Text("Ne") } }
    )
}

// ======================= Pagalbiniai =======================

@Composable
fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = 8.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
}

@Composable
fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Num(label: String, value: Float, range: ClosedFloatingPointRange<Float>, int: Boolean = false, onChange: (Float) -> Unit) {
    Text("$label: " + if (int) value.toInt().toString() else "%.3f".format(value), style = MaterialTheme.typography.bodySmall)
    Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chips(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) }) }
    }
}
