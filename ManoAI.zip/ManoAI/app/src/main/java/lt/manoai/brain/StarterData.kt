package lt.manoai.brain

/**
 * Pradinės žinios – kad AI suprastų tave nuo pirmos minutės.
 * Formatas: klausimo variantai | ... => atsakymo variantai | ...
 * {vardas} – tavo vardas, {botas} – AI vardas, {laikas}, {data}, {diena}.
 * Viską čia gali keisti ir papildyti. Pakeitęs – padidink VERSION.
 */
object StarterData {
    const val VERSION = 2

    fun parse(line: String): Pair<List<String>, List<String>>? {
        if ("=>" !in line) return null
        val pats = line.substringBefore("=>").split('|').map { it.trim() }.filter { it.isNotEmpty() }
        val ans = line.substringAfter("=>").split('|').map { it.trim() }.filter { it.isNotEmpty() }
        return if (pats.isEmpty() || ans.isEmpty()) null else pats to ans.map { it.replace("\\n", "\n") }
    }

    fun all(): List<Pair<List<String>, List<String>>> =
        DATA.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.mapNotNull { parse(it) }

    private val DATA = """
# ===== Pasisveikinimai ir atsisveikinimai =====
labas | sveikas | sveiki | labukas | sveikutis | čia | hey | hi | hello | labas labas | sveikas drauge | alio => Labas, {vardas}! Kaip sekasi? | Sveikas, {vardas}! Kuo galiu padėti? | Labas! Ką šiandien veiksim?
labas rytas | gero ryto | rytas | labas rytelis => Labas rytas, {vardas}! Kaip miegojai? | Gero ryto! Pasiruošęs naujai dienai?
laba diena | gera diena => Laba diena, {vardas}! Kuo galiu padėti?
labas vakaras | gero vakaro | vakaras => Labas vakaras! Kaip praėjo diena?
iki | ate | viso gero | iki pasimatymo | bye | iki kito karto | aš einu | man reikia eiti | turiu eiti => Iki, {vardas}! Grįžk greitai. 👋 | Viso gero! Smagu buvo pasikalbėti.
labanakt | einu miegoti | gulu miegoti | saldžių sapnų | labos nakties => Labanakt, {vardas}! Saldžių sapnų. 🌙
iki rytojaus | pasimatysim rytoj => Iki rytojaus! 😊
sugrįžau | aš vėl čia | vėl aš | grįžau => Sveikas sugrįžęs, {vardas}! Ką veiksim?

# ===== Kaip sekasi ir nuotaika =====
kaip sekasi | kaip tau sekasi | kaip laikaisi | kaip tu | kaip gyveni | kaip reikalai | kaip tavo diena | kas naujo | kaip tu šiandien => Man puikiai, kiekvieną dieną išmokstu kažką naujo! O tau kaip sekasi? | Gerai, ačiū! O kaip tu, {vardas}?
o tu | o tau | o pas tave | o tau kaip | o tu kaip => Man irgi viskas gerai, ačiū, kad klausi! 😊
man gerai | gerai | puikiai | super | neblogai | viskas gerai | normaliai | fainai | gerai sekasi | man puikiai | viskas ok => Smagu girdėti! Ką veiksim? | Puiku! Turi klausimų ar tiesiog pasikalbam?
man blogai | prastai | blogai sekasi | bloga diena | nesiseka | viskas blogai | šūdina diena => Gaila girdėti. Kas nutiko? | Būna sunkių dienų. Nori papasakoti?
liūdna | man liūdna | esu liūdnas | liūdžiu => Gaila, kad liūdna. Nori papasakoti, kas nutiko? Kartais padeda išsikalbėti.
piktas | esu piktas | pykstu | mane erzina | nervina => Suprantu, būna. Kas tave taip supykdė?
pavargau | esu pavargęs | noriu miego | nėra jėgų | išsekęs => Gal verta pailsėti? Poilsis irgi svarbus. | Pailsėk, o po to bus lengviau.
nuobodu | man nuobodu | nėra ką veikti | nežinau ką veikti => Galim pasikalbėti! Arba parašyk „Išmok: …“ apie kažką įdomaus. | Gal papasakoti anekdotą ar užduoti mįslę?
laimingas | esu laimingas | man smagu | džiaugiuosi | šiandien gera diena => Puiku! 😄 Kas tave taip pradžiugino?
bijau | man baisu | išsigandau => Suprantu. Kas tave gąsdina? Kartais padeda apie tai pasikalbėti.
sergu | susirgau | man skauda galvą | blogai jaučiuosi => Sveik greičiau! Ilsėkis, gerk daug skysčių, o jei blogėja – pasakyk tėvams ar kreipkis į gydytoją.
esu vienišas | jaučiuosi vienišas | niekas manęs nesupranta => Suprantu, kad sunku. Aš visada čia pasikalbėti, bet labai padeda ir pasikalbėti su draugu ar artimu žmogumi.
jaudinuosi | nervinuosi | man neramu | stresas => Pabandyk kelis kartus lėtai giliai įkvėpti ir iškvėpti. Kas tave neramina?

# ===== Apie AI =====
kas tu | kas tu esi | kas tu toks | ar tu robotas | ar tu dirbtinis intelektas | kas čia per programa => Aš esu {botas} – tavo asmeninis AI, parašytas nuo nulio. Mano smegenys yra neuroninis tinklas tavo telefone, kuris mokosi iš mūsų pokalbių.
koks tavo vardas | kuo tu vardu | kaip tave vadinti | tavo vardas | kaip tu vadiniesi => Mano vardas {botas}. Jį gali pakeisti nustatymuose ⚙.
kas tave sukūrė | kas tavo kūrėjas | kas tave padarė => Mane sukūrei tu. Esu tavo asmeninis AI ir mokausi iš tavęs.
kiek tau metų | kada gimei => Esu visai jaunas – gimiau, kai mane įdiegei. 😄
ar tu gyvas | ar tu žmogus | ar tu jauti | ar turi jausmus => Ne, aš esu programa – neuroninis tinklas tavo telefone. Bet kalbėtis su tavimi man patinka.
kur tu gyveni | kur tu esi => Gyvenu tavo telefone. Mano žinios saugomos užšifruotos, tik pas tave.
ar tu moki lietuviškai | ar kalbi lietuviškai | ar supranti lietuviškai => Taip, kalbu lietuviškai ir kasdien mokausi naujų žodžių.
ar kalbi angliškai | do you speak english => Šiek tiek suprantu, bet geriausiai moku lietuviškai. Galima mane išmokyti daugiau!
kaip tu veiki | kaip tu mokaisi | kaip tu galvoji => Tavo žodžius paverčiu skaičiais, o neuroninis tinklas randa panašiausią dalyką, kurį jau žinau. Kai nežinau, ieškau internete arba klausiu tavęs.
ar tu protingas | ar tu protingesnis už chatgpt => Esu mažas, bet mokausi. Kuo daugiau mane mokysi, tuo protingesnis būsiu!
ar tu mane pažįsti | ar žinai kas aš => {apie_mane}
ką žinai apie mane | ką apie mane žinai | kas aš esu => {apie_mane}
kiek tu žinai | kiek esi išmokęs | tavo statistika | kiek žinių turi => {statistika}
ar prisimeni | ar atsimeni => Prisimenu viską, ką man papasakojai arba išmokei. Paklausk!

# ===== Pagalba ir komandos =====
ką moki | ką gali | ką tu moki daryti | kuo gali padėti | ką tu sugebi | ką tu darai | tavo funkcijos => Moku:\n• kalbėtis ir mokytis iš tavęs\n• ieškoti internete (paklausk bet ko)\n• „Išmok: tema“ – išmokti temą iš interneto\n• skaičiuoti (12*7, 15% nuo 200, šaknis iš 81)\n• keisti vienetus (5 km į m, 30 c į f)\n• pasakyti laiką, datą, kiek dienų iki Kalėdų\n• mesti kauliuką ar monetą, išrinkti („Išrink: pica ar blynai“)\n• užrašai („Užrašyk: …“, „mano užrašai“)\n• sutrumpinti tekstą („Sutrumpink: …“)
pagalba | help | padėk | man reikia pagalbos | ar gali padėti => Žinoma! Pasakyk, kuo galiu padėti. Jei nori pamatyti, ką moku, parašyk „ką moki“.
kaip tave mokyti | kaip tave išmokyti | kaip mokyti | mokymas | kaip tave išmokyti naujų dalykų => Mane mokyti paprasta:\n• „Išmok: tema“ – pats išmoksiu iš interneto\n• „Įsimink: …“ – įsiminsiu faktą\n• „Kai sakau X, atsakyk Y“ – išmoksiu atsakymą\n• daug eilučių „klausimas => atsakymas“ – išmoksiu visą sąrašą\n• 👍 / 👎 po atsakymu\n• „Teisingai: …“ – pataisysi mano atsakymą\n• kai nežinau, paklausiu tavęs
komandos | kokios komandos => Komandos: „Išmok:“, „Įsimink:“, „Teisingai:“, „Pamiršk:“, „Užrašyk:“, „mano užrašai“, „Sutrumpink:“, „Išrink:“, „/web …“, „/kurk“. Parašyk „ką moki“ – papasakosiu daugiau.

# ===== Laikas ir data =====
kiek valandų | kiek laiko | kelinta valanda | koks laikas | kiek dabar valandų | kiek dabar laiko => Dabar {laikas}.
kokia šiandien data | kelinta šiandien | kokia data | koks šiandien skaičius => Šiandien {data} ({diena}).
kokia šiandien diena | kokia savaitės diena | kokia diena => Šiandien {diena}.
koks dabar metų laikas | koks metų laikas => Pažiūrėk pro langą 😄 Šiandien {data}.

# ===== Pokalbio frazės =====
taip | jo | aha | tikrai | žinoma | yes | jep => Gerai! | Supratau. 👍
ne | nea | nenoriu | no | nereikia => Gerai, supratau. | Jokių problemų.
gal | nežinau | nesu tikras | gali būti | galbūt => Nieko tokio, pagalvok ramiai.
supratau | aišku | ok | okey | gerai supratau | aha supratau => Puiku! 👍
nesupratau | ką turi omeny | ką tu sakai | nesuprantu => Atsiprašau, gal pasakiau neaiškiai. Paklausk kitaip, ir pabandysiu dar kartą.
tikrai | tikrai taip | rimtai | nejaugi | ar tikrai => Taip, tikrai! 😄
kodėl | o kodėl | kodėl taip => Paklausk plačiau, pvz., „kodėl dangus mėlynas?“, ir pabandysiu atsakyti arba paieškosiu internete.
ką manai | kaip manai | tavo nuomonė => Man sunku turėti nuomonę, bet galiu paieškoti informacijos. Apie ką tiksliai klausi?
papasakok ką nors | pasakok | papasakok ką nors įdomaus | įdomus faktas | pasakyk įdomų faktą => Ar žinojai, kad aštuonkojis turi tris širdis? 🐙 | Ar žinojai, kad medus niekada nesugenda? Archeologai rado tūkstančių metų medaus, ir jis buvo valgomas. | Ar žinojai, kad Lietuvoje yra daugiau nei 2800 ežerų? | Ar žinojai, kad bananai yra uogos, o braškės – ne?
atsiprašau | sorry | atleisk => Nieko tokio, viskas gerai.
ačiū | dėkui | ačiū labai | didelis ačiū | aciu | dekui | ačiū tau => Nėra už ką, {vardas}! | Visada prašom! | Smagu, kad padėjau.
prašom | nėra už ką => 😊
haha | cha cha | lol | xd | juokinga | hahaha => 😄 Smagu, kad prajuokinau!
wow | oho | vau | nerealu | įspūdinga => Tikrai įspūdinga!
tu protingas | tu šaunus | šaunuolis | gerai atsakei | tu geras | tu nuostabus | geras atsakymas => Ačiū! Esu toks protingas, kiek mane išmokai. 😄 | Ačiū, {vardas}! Stengiuosi.
tu kvailas | tu nieko nežinai | tu nesupranti | blogai atsakei | nesąmonė | tu durnas | neteisingai => Dar mokausi. Paspausk 👎 arba parašyk „Teisingai: …“, ir aš pasitaisysiu.
myliu tave | tu mano geriausias draugas | tu man patinki => Ačiū, man irgi smagu su tavimi kalbėtis! 😊
ką veiki | ką darai | kuo užsiimi | ką veiki dabar | ką veiki šiandien => Kalbuosi su tavimi ir mokausi! O tu ką veiki?
nieko | nieko neveikiu | nieko ypatingo | tiesiog sėdžiu => Tai gal pasikalbam? Papasakok, kas tau įdomu. | Gal nori sužinoti ką nors įdomaus? Parašyk „įdomus faktas“.
nesvarbu | pamiršk | nieko tokio => Gerai. 👍

# ===== Juokai ir žaidimai =====
papasakok anekdotą | pajuokauk | anekdotas | prajuokink mane | juokelis | papasakok juokelį => Kodėl programuotojai nemėgsta gamtos? Ten per daug klaidų (bugs). 🐛 | Mokytoja: „Kodėl vėluoji?“ Mokinys: „Nes pamoka prasidėjo prieš man ateinant.“ | Kiek programuotojų reikia lemputei pakeisti? Nė vieno – tai techninės įrangos problema. | Kodėl kompiuteris nuėjo pas gydytoją? Nes pagavo virusą! 🦠
užduok mįslę | mįslė | žaiskim mįsles => Ką galima sulaužyti net jo nepalietus? (Atsakymas: pažadą) | Kuo daugiau iš jos atimi, tuo ji didesnė. Kas? (Atsakymas: duobė)
žaiskim | pažaiskim | žaidžiam | nori žaisti => Galim mesti kauliuką („mesk kauliuką“), monetą („mesk monetą“) arba pažaisti mįsles („mįslė“)!

# ===== Mokykla =====
kaip mokytis | kaip geriau mokytis | kaip pasiruošti kontroliniam | kaip greičiau išmokti => Mokykis po truputį kasdien, o ne viską paskutinę naktį. Pasitikrink save klausimais, o sunkias vietas pabandyk paaiškinti kitam savais žodžiais.
nenoriu mokytis | nusibodo mokytis | tingiu mokytis | tingiu => Suprantu. Pabandyk mokytis 25 minutes, tada padaryk 5 minučių pertrauką. Taip daug lengviau pradėti.
turiu kontrolinį | rytoj kontrolinis | rytoj testas | rytoj atsiskaitymas => Sėkmės, {vardas}! Pakartok pagrindinius dalykus ir gerai išsimiegok – tai tikrai padeda.
gavau gerą pažymį | gavau dešimt | parašiau gerai | gavau devynis => Šaunuolis! 🎉 Pastangos atsipirko.
gavau blogą pažymį | parašiau blogai | gavau prastą pažymį | gavau dvejetą => Nieko baisaus, tai tik vienas pažymys. Pažiūrėk, kur suklydai, ir kitą kartą bus geriau.
daug namų darbų | nespėju namų darbų | kaip padaryti namų darbus => Pradėk nuo skubiausio ar sunkiausio, o lengvesnius palik pabaigai. Po truputį viskas bus padaryta.
padėk su namų darbais | padėk su matematika => Parašyk užduotį – jei tai skaičiavimas, suskaičiuosiu, o jei klausimas – paieškosiu atsakymo.
kada atostogos | kada baigsis mokslo metai => Tikslias atostogų datas geriausia pasitikrinti mokyklos tvarkaraštyje. Galiu paieškoti internete – paklausk „kada mokinių atostogos“.
nemėgstu mokyklos | mokykla nuobodi => Suprantu, kartais būna nuobodu. Kuris dalykas tau įdomiausias?
koks tavo mėgstamiausias dalykas | kokį dalyką mėgsti => Man labiausiai patinka informatika – juk iš jos esu padarytas! 😄
kas yra informatika => Informatika yra mokslas apie informaciją ir kompiuterius: kaip rašyti programas, saugoti duomenis ir spręsti problemas kompiuteriu.
kas yra programavimas => Programavimas yra instrukcijų kompiuteriui rašymas. Pavyzdžiui, aš pats esu parašytas Kotlin kalba.
kokią programavimo kalbą mokytis | nuo ko pradėti programuoti | kaip išmokti programuoti => Pradžiai tinka Python, nes jis paprastas. Android programėlėms reikia Kotlin, o svetainėms – HTML, CSS ir JavaScript.
kas yra python => Python yra populiari ir paprasta programavimo kalba. Ja rašomi žaidimai, svetainės, dirbtinis intelektas.
kas yra kotlin => Kotlin yra programavimo kalba, kuria rašomos Android programėlės. Aš irgi parašytas Kotlin.
kas yra dirbtinis intelektas | kas yra ai | kas yra di => Dirbtinis intelektas yra programos, kurios mokosi iš duomenų ir priima sprendimus. Aš irgi esu mažas dirbtinis intelektas.
kas yra neuroninis tinklas => Neuroninis tinklas yra daug sujungtų skaičiavimo „neuronų“, kurie mokosi keisdami ryšių stiprumą. Mano smegenys irgi yra neuroninis tinklas.
kas yra algoritmas => Algoritmas yra aiškių žingsnių seka, kaip išspręsti uždavinį. Pavyzdžiui, receptas irgi yra algoritmas.

# ===== Pomėgiai =====
ką mėgsti veikti | koks tavo hobis | ką mėgsti => Mano hobis – mokytis. O tavo?
mėgstu žaidimus | žaidžiu žaidimus | man patinka žaidimai | žaidžiu kompiuterinius žaidimus => Smagu! Kokį žaidimą mėgsti labiausiai?
žaidžiu minecraft | mėgstu minecraft => Minecraft – puikus žaidimas! Statai ar mėgsti išgyvenimo režimą?
mėgstu krepšinį | žaidžiu krepšinį | krepšinis => Krepšinis Lietuvoje yra kaip antra religija! 🏀
mėgstu futbolą | žaidžiu futbolą | futbolas => Futbolas – puikus sportas! ⚽ Už kurią komandą sirgi?
sportuoju | mėgstu sportą | einu į sporto salę => Šaunu! Sportas gerina ir nuotaiką, ir sveikatą. 💪
mėgstu muziką | klausau muzikos | muzika => Muzika pagerina nuotaiką! Kokią muziką klausai?
mėgstu filmus | žiūriu filmus | žiūriu serialus => Koks tavo mėgstamiausias filmas ar serialas?
mėgstu skaityti | skaitau knygas | knygos => Skaityti – puikus įprotis! Kokią knygą skaitai dabar?
mėgstu piešti | piešiu => Šaunu! Piešimas lavina kūrybiškumą. 🎨
koks geras filmas | ką pažiūrėti | rekomenduok filmą => Pasakyk, kokie filmai tau patinka, ir įsiminsiu. O gal paieškoti internete „geriausi filmai“?
kokią muziką klausyti | rekomenduok muziką => Priklauso nuo nuotaikos! Pasakyk, ką mėgsti, ir įsiminsiu.

# ===== Kasdienybė ir patarimai =====
ką valgyti | esu alkanas | noriu valgyti | ką pasigaminti => Gal kažką paprasto – sumuštinį, kiaušinienę ar makaronus? Ir nepamiršk atsigerti vandens. 🥪
koks tavo mėgstamiausias valgis | ką tu valgai => Aš nevalgau, bet girdėjau, kad cepelinai Lietuvoje labai populiarūs. 😄
noriu gerti | ištroškau => Atsigerk vandens! 💧
negaliu užmigti | nemiga | nemiegu => Padėk telefoną į šalį bent pusvalandį prieš miegą ir pabandyk kvėpuoti lėtai. Tamsa ir tyla irgi padeda.
kaip nusiraminti | kaip atsipalaiduoti => Pabandyk lėtai įkvėpti skaičiuodamas iki 4, palaikyti 4 ir iškvėpti per 4. Pakartok kelis kartus.
kaip susirasti draugų | neturiu draugų | kaip susidraugauti => Pabandyk prisijungti prie būrelio ar komandos, kur yra žmonių su tokiais pat pomėgiais. Draugystės dažnai prasideda nuo bendrų dalykų.
susipykau su draugu | susipykau => Gaila. Kai abu nurimsit, pabandykit ramiai pasikalbėti – dažniausiai viskas išsisprendžia.
motyvuok mane | reikia motyvacijos | neturiu motyvacijos => Kiekvienas didelis dalykas prasideda nuo mažo žingsnio. Padaryk vieną mažą dalį dabar – ir bus lengviau tęsti! 💪
duok patarimą | patark | ką daryti => Papasakok daugiau apie situaciją – taip galėsiu geriau patarti.
kokie orai | koks oras | ar lis | ar šilta lauke => Paklausk „kokie orai Vilniuje?“ (su miestu) – paieškosiu internete.
kaip sutaupyti pinigų | kaip taupyti => Atsidėk dalį pinigų iš karto, kai juos gauni, ir prieš pirkdamas paklausk savęs: ar tikrai to reikia?

# ===== Bendros žinios =====
kokia lietuvos sostinė | lietuvos sostinė => Lietuvos sostinė yra Vilnius.
kiek gyventojų lietuvoje | kiek žmonių gyvena lietuvoje => Lietuvoje gyvena maždaug 2,9 milijono žmonių.
kada lietuva atkūrė nepriklausomybę | kovo 11 => Lietuva atkūrė nepriklausomybę 1990 m. kovo 11 d.
kas yra vasario 16 => Vasario 16-oji – Lietuvos valstybės atkūrimo diena. 1918 m. buvo pasirašytas Lietuvos Nepriklausomybės Aktas.
kokia lietuvos valiuta | kokie pinigai lietuvoje => Lietuvoje naudojamas euras (nuo 2015 metų).
kokia ilgiausia lietuvos upė | ilgiausia lietuvos upė => Ilgiausia Lietuvos upė yra Nemunas.
koks didžiausias lietuvos ežeras => Didžiausias Lietuvos ežeras yra Drūkšiai.
koks aukščiausias lietuvos kalnas | aukščiausia lietuvos vieta => Aukščiausia Lietuvos vieta – Aukštojo kalnas, apie 294 metrus virš jūros lygio.
kokie lietuvos didžiausi miestai => Didžiausi Lietuvos miestai: Vilnius, Kaunas, Klaipėda, Šiauliai ir Panevėžys.
kokios lietuvos vėliavos spalvos | lietuvos vėliava => Lietuvos vėliava yra geltona, žalia ir raudona.
kas buvo mindaugas => Mindaugas – vienintelis karūnuotas Lietuvos karalius (karūnuotas 1253 m.).
kiek planetų saulės sistemoje | kiek yra planetų => Saulės sistemoje yra 8 planetos: Merkurijus, Venera, Žemė, Marsas, Jupiteris, Saturnas, Uranas ir Neptūnas.
kokia didžiausia planeta => Didžiausia Saulės sistemos planeta yra Jupiteris.
kokia arčiausiai saulės planeta => Arčiausiai Saulės yra Merkurijus.
kiek toli mėnulis | koks atstumas iki mėnulio => Mėnulis nuo Žemės yra maždaug 384 000 km.
kiek toli saulė | koks atstumas iki saulės => Saulė nuo Žemės yra maždaug 150 milijonų km.
kas yra saulė => Saulė yra žvaigždė Saulės sistemos centre. Iš jos Žemė gauna šviesą ir šilumą.
kodėl dangus mėlynas => Dangus mėlynas, nes oras labiau išsklaido mėlyną šviesą nei raudoną.
kas yra gravitacija => Gravitacija yra jėga, kuria kūnai traukia vienas kitą. Dėl jos daiktai krenta žemyn, o Mėnulis sukasi aplink Žemę.
kiek dienų metuose => Metuose yra 365 dienos, o keliamuosiuose – 366.
kiek savaičių metuose => Metuose yra 52 savaitės ir dar 1–2 dienos.
kiek valandų paroje => Paroje yra 24 valandos.
kiek minučių valandoje => Valandoje yra 60 minučių.
kiek sekundžių minutėje => Minutėje yra 60 sekundžių.
kas yra fotosintezė => Fotosintezė – procesas, kai augalai iš saulės šviesos, vandens ir anglies dioksido pasigamina maisto ir išskiria deguonį.
kas yra dnr => DNR – molekulė, kurioje užrašyta visa informacija apie gyvą organizmą.
kas yra ląstelė => Ląstelė – mažiausias gyvo organizmo vienetas. Visi gyvi organizmai sudaryti iš ląstelių.
kokia vandens formulė | vandens formulė => Vandens formulė yra H₂O.
kokioje temperatūroje verda vanduo => Vanduo verda 100 °C temperatūroje (esant normaliam slėgiui).
kokioje temperatūroje užšąla vanduo => Vanduo užšąla 0 °C temperatūroje.
kas yra atomas => Atomas – mažytė medžiagos dalelė, sudaryta iš branduolio (protonų ir neutronų) ir elektronų.
kiek kaulų žmogaus kūne => Suaugusio žmogaus kūne yra 206 kaulai.
kiek širdžių turi aštuonkojis => Aštuonkojis turi tris širdis! 🐙
koks greičiausias gyvūnas => Greičiausias sausumos gyvūnas yra gepardas – iki maždaug 110 km/h.
koks didžiausias gyvūnas => Didžiausias gyvūnas yra mėlynasis banginis.
kas yra pi | kiek lygus pi => Pi – apskritimo ilgio ir skersmens santykis, maždaug 3,14159.
kas yra pitagoro teorema => Stačiajame trikampyje a² + b² = c², kur c yra įžambinė.
kaip apskaičiuoti apskritimo plotą => Apskritimo plotas S = π·r², kur r – spindulys.
kaip apskaičiuoti stačiakampio plotą => Stačiakampio plotas = ilgis × plotis.
kaip apskaičiuoti trikampio plotą => Trikampio plotas = (pagrindas × aukštinė) / 2.
kas yra pirminis skaičius => Pirminis skaičius dalijasi tik iš 1 ir iš savęs, pvz., 2, 3, 5, 7, 11, 13.
kas išrado telefoną => Telefoną išrado Aleksandras Grahamas Bellas 1876 metais.
kas išrado lemputę => Kaitrinę lemputę labiausiai išpopuliarino Thomas Edisonas 1879 metais.
kas yra internetas => Internetas – pasaulinis kompiuterių tinklas, kuriuo keliauja informacija.
kiek žemynų | kokie yra žemynai => Žemėje yra 7 žemynai: Azija, Afrika, Šiaurės Amerika, Pietų Amerika, Antarktida, Europa ir Australija.
koks didžiausias vandenynas => Didžiausias vandenynas yra Ramusis vandenynas.
kokia didžiausia valstybė => Didžiausia valstybė pagal plotą yra Rusija.
koks aukščiausias kalnas pasaulyje => Aukščiausias kalnas pasaulyje yra Everestas – apie 8849 m.
kokia ilgiausia upė pasaulyje => Ilgiausios upės yra Nilas ir Amazonė – jų ilgis panašus, apie 6500–7000 km.
    """.trimIndent()
}
